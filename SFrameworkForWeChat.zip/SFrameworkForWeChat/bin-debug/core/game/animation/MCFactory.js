var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var MCFactory = (function () {
            function MCFactory() {
                this.init();
            }
            MCFactory.prototype.init = function () {
                this._factorys = {};
            };
            MCFactory.prototype.getMovieClipData = function (jsons, pngs, key) {
                var mcFactory = this._factorys[key];
                if (!mcFactory) {
                    mcFactory = new egret.MovieClipDataFactory(jsons, pngs);
                    this._factorys[key] = mcFactory;
                    return mcFactory.generateMovieClipData(key);
                }
                else {
                    return mcFactory.generateMovieClipData(key);
                }
            };
            return MCFactory;
        }());
        game.MCFactory = MCFactory;
        __reflect(MCFactory.prototype, "shao.game.MCFactory");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=MCFactory.js.map