var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        /**
         * 用于处理无方向的动画信息
         * @author builder
         *
         */
        var AniInfo = (function () {
            function AniInfo() {
                /**
                 * 加载状态
                 */
                this.state = 0 /* UNREQUEST */;
            }
            /**
             * 绑定渲染器
             * @param render
             */
            AniInfo.prototype.bind = function (render) {
                var state = this.state;
                if (state != 2 /* COMPLETE */) {
                    if (!this._refList) {
                        this._refList = [];
                    }
                    this._refList.push(render);
                    if (state == 0 /* UNREQUEST */) {
                        this.loadData();
                    }
                }
            };
            /**加载数据 */
            AniInfo.prototype.loadData = function () {
                // if (this.key == AniDefine.BUTTON_EFFECT_LONG) {
                //     console.log(`加载：${this.key}`);
                // }
                var uri = game.ResPrefix.ANI + this.key + "/" + "d.json"; //+ UnitResource.DATA_JSON;
                this.jsonurl = shao.ConfigUtils.getResUrl(uri, true);
                uri = game.ResPrefix.ANI + this.key + "/" + "d.png";
                this.pngurl = shao.ConfigUtils.getResUrl(uri, true);
                RES.getResByUrl(this.jsonurl, this.dataLoadComplete, this, RES.ResourceItem.TYPE_JSON);
                RES.getResByUrl(this.pngurl, this.dataLoadComplete, this, RES.ResourceItem.TYPE_IMAGE);
                this.state = 1 /* REQUESTING */;
            };
            /**
             * 资源加载完成
             */
            AniInfo.prototype.dataLoadComplete = function (data, key) {
                if (key == this.jsonurl)
                    this.loadJson = data;
                if (key == this.pngurl)
                    this.loadPng = data;
                if (!this.loadJson || !this.loadPng)
                    return;
                // if (key == this.url) {
                //     if (data) {
                //         this.init(this.key, data);
                if (this._refList) {
                    for (var _i = 0, _a = this._refList; _i < _a.length; _i++) {
                        var render = _a[_i];
                        render.callback();
                    }
                }
                // } else {// 不做加载失败的处理
                //     this.state = RequestState.COMPLETE;
                // }
                this._refList = undefined;
                // }
                this.state = 2 /* COMPLETE */;
            };
            /**
             * 和渲染器解除绑定
             * @param render
             */
            AniInfo.prototype.loose = function (render) {
                var _refList = this._refList;
                if (_refList) {
                    _refList.remove(render);
                }
            };
            AniInfo.prototype.init = function (key, data) {
                // super.init(key, data[0]);
                // let resID = ResPrefix.ANI + key;
                // var res: UnitResource = <UnitResource>ResourceManager.getResource(resID);
                // if (!res) {
                //     res = new UnitResource(resID, this.splitInfo);
                //     ResourceManager.regResource(resID, res);
                // }
                // res.decodeData(data[1]);
                // this._resources = res;
                // this.state = RequestState.COMPLETE;
                // this._rawData = data[1];
            };
            return AniInfo;
        }());
        game.AniInfo = AniInfo;
        __reflect(AniInfo.prototype, "shao.game.AniInfo");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=AniInfo.js.map