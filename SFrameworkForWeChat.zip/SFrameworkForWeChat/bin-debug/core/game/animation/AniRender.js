var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var AniPlayState;
        (function (AniPlayState) {
            AniPlayState[AniPlayState["Standby"] = 0] = "Standby";
            AniPlayState[AniPlayState["Playing"] = 1] = "Playing";
            AniPlayState[AniPlayState["Recycled"] = 2] = "Recycled";
        })(AniPlayState = game.AniPlayState || (game.AniPlayState = {}));
        var AniRender = (function () {
            function AniRender() {
                /**
                 * 0 初始化，未运行
                 * 1 正在运行
                 * 2 已回收
                 */
                this.state = AniPlayState.Standby;
                this._guid = 0;
                this.displaymc = new egret.MovieClip();
            }
            Object.defineProperty(AniRender.prototype, "guid", {
                /**
                 * 特效标识
                 */
                get: function () {
                    return this._guid;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AniRender.prototype, "uri", {
                get: function () {
                    return this._uri;
                },
                enumerable: true,
                configurable: true
            });
            /**
             * 获取ANI动画
             *
             * @static
             * @param {string} uri    动画地址
             * @param {number} [guid] 外部设置动画的guid
             * @returns (description)
             */
            AniRender.getAni = function (uri, guid) {
                if (!uri)
                    return;
                // let aniDict: any = DataLocator.getData(ConfigKey.ANI);
                var aniDict = this.aniDict;
                if (!aniDict)
                    aniDict = {};
                var aniInfo = aniDict[uri];
                if (!aniInfo) {
                    aniInfo = new game.AniInfo();
                    aniInfo.key = uri;
                    aniDict[uri] = aniInfo;
                    this.aniDict = aniDict;
                }
                // let display = ResourceBitmap.getInstance();
                var ani = this._pool.getInstance();
                ani._aniInfo = aniInfo;
                // ani.display = display;
                if (aniInfo.state == 2 /* COMPLETE */) {
                    ani.displaymc.movieClipData = shao.getInstance(game.MCFactory).getMovieClipData(aniInfo.loadJson, aniInfo.loadPng, uri);
                }
                else {
                    aniInfo.bind(ani);
                }
                ani._guid = guid === void 0 ? this.guid++ : guid;
                ani._uri = uri;
                this._renderByGuid[ani._guid] = ani;
                return ani;
            };
            AniRender.prototype.callback = function () {
                if (this._aniInfo) {
                    var display = this.displaymc;
                    var aniInfo = this._aniInfo;
                    display.movieClipData = shao.getInstance(game.MCFactory).getMovieClipData(aniInfo.loadJson, aniInfo.loadPng, this._uri);
                    this.play(-1);
                }
            };
            AniRender.prototype.play = function (playTimes) {
                var display = this.displaymc;
                this.state = AniPlayState.Playing;
                if (display.movieClipData) {
                    display.play(playTimes);
                    if (this.frameRate) {
                        display.frameRate = this.frameRate;
                    }
                }
            };
            AniRender.prototype.recycle = function () {
                AniRender._pool.recycle(this);
            };
            AniRender.prototype.onRecycle = function () {
                // if (DEBUG) {
                //     if ($gm._recordAni) {
                //         delete $gm._aniRecords[this._guid];
                //     }
                // }
                delete AniRender._renderByGuid[this._guid];
                this.state = AniPlayState.Recycled;
                var display = this.displaymc;
                if (display) {
                    display.movieClipData = undefined;
                    shao.removeDisplay(display);
                }
                if (this._aniInfo) {
                    this._aniInfo.loose(this);
                    this._aniInfo = undefined;
                }
                this.frameRate = 0;
                this._guid = 0;
            };
            /***********************************静态方法****************************************/
            AniRender._renderByGuid = {};
            AniRender.guid = 1;
            AniRender._pool = new shao.RecyclablePool(AniRender);
            return AniRender;
        }());
        game.AniRender = AniRender;
        __reflect(AniRender.prototype, "shao.game.AniRender", ["shao.IRecyclable"]);
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=AniRender.js.map