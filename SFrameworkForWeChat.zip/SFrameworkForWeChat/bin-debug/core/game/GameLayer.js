var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        /**
        * GameLayer
        * 用于后期扩展
        */
        var GameLayer = (function (_super) {
            __extends(GameLayer, _super);
            function GameLayer(id) {
                var _this = _super.call(this) || this;
                _this.id = id;
                return _this;
            }
            return GameLayer;
        }(egret.Sprite));
        game.GameLayer = GameLayer;
        __reflect(GameLayer.prototype, "shao.game.GameLayer");
        /**
         * 需要对子对象排序的层
         */
        var SortedLayer = (function (_super) {
            __extends(SortedLayer, _super);
            function SortedLayer() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SortedLayer.prototype.$doAddChild = function (child, index, notifyListeners) {
                if (notifyListeners === void 0) { notifyListeners = true; }
                if ("depth" in child) {
                    game.GameEngine.invalidateSort();
                    return _super.prototype.$doAddChild.call(this, child, index, notifyListeners);
                }
                else {
                    throw new Error("Only IDepth can be added to this Layer(" + this.id + ")");
                }
            };
            /**
             * 进行排序
             */
            SortedLayer.prototype.sort = function () {
                //对子集排序
                this.$children.sort(function (a, b) {
                    return a["depth"] - b["depth"];
                });
            };
            return SortedLayer;
        }(GameLayer));
        game.SortedLayer = SortedLayer;
        __reflect(SortedLayer.prototype, "shao.game.SortedLayer");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=GameLayer.js.map