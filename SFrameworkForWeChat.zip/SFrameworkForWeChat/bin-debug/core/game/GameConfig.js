/**
 * 游戏的常量的接口定义
 * 子项目自身实现接口
 * @author builder
 */
var shao;
(function (shao) {
    var game;
    (function (game) {
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=GameConfig.js.map