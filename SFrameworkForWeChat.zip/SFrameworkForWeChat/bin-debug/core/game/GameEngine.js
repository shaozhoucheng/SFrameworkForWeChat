var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var layerConfigs = {};
        /**
         * 用于做斜45°视角2d游戏的引擎<br/>
         * @author builder
         * 2016-02-17 目标：1 完成地图的平铺显示
         *                  2 完成人物播放
         *
         */
        var GameEngine = (function (_super) {
            __extends(GameEngine, _super);
            function GameEngine(stage) {
                var _this = _super.call(this) || this;
                _this._layers = [];
                /**
                 * 排序层
                 */
                _this._sortedLayers = [];
                _this.transSceneRect = shao.Temp.pipeFunction;
                _this.initConfigs();
                _this._stage = stage;
                _this.initLayers();
                stage.on(egret.Event.ENTER_FRAME, _this.render, _this);
                return _this;
            }
            GameEngine.init = function (stage) {
                var engine = new GameEngine(stage);
                GameEngine.instance = engine;
            };
            GameEngine.prototype.initConfigs = function () {
                new LayerConfig(9999 /* Out */);
                new LayerConfig(9000 /* Tip */);
                new LayerConfig(8900 /* TopUI */, 8000 /* UI */);
                new LayerConfig(8700 /* PopUI */, 8000 /* UI */);
                new LayerConfig(8300 /* MiddleUI */, 8000 /* UI */);
                new LayerConfig(8100 /* BaseUI */, 8000 /* UI */);
                new LayerConfig(8000 /* UI */);
                new LayerConfig(1000 /* Game */);
                new LayerConfig(1900 /* Mask */, 1000 /* Game */);
                new LayerConfig(1800 /* TopEffect */, 1000 /* Game */);
                new LayerConfig(1700 /* GameScene */, 1000 /* Game */);
                new LayerConfig(1790 /* CeilEffect */, 1700 /* GameScene */);
                new LayerConfig(1780 /* SortedUI */, 1700 /* GameScene */, game.SortedLayer);
                new LayerConfig(1770 /* GameEffect */, 1700 /* GameScene */);
                new LayerConfig(1760 /* Sorted */, 1700 /* GameScene */, game.SortedLayer);
                new LayerConfig(1750 /* Bottom */, 1700 /* GameScene */);
                new LayerConfig(1740 /* BottomEffect */, 1700 /* GameScene */);
                new LayerConfig(1730 /* Background */, 1700 /* GameScene */);
                new LayerConfig(1710 /* Mini */, 1700 /* GameScene */);
            };
            /**
             * 单位坐标发生变化时调用
             */
            GameEngine.invalidateSort = function () {
                GameEngine._sortDirty = true;
            };
            Object.defineProperty(GameEngine.prototype, "viewRect", {
                get: function () {
                    return this._viewRect;
                },
                enumerable: true,
                configurable: true
            });
            /**
             * 地图渲染层
             */
            // protected _background: TileMapLayer;
            /**
             * 当前地图
             */
            // protected _currentMap: MapInfo;
            /**
             * 获取或创建容器
             */
            GameEngine.prototype.getLayer = function (id) {
                var layers = this._layers;
                var layer = layers[id];
                if (!layer) {
                    var cfg = layerConfigs[id];
                    if (!cfg) {
                        return undefined;
                    }
                    var ref = cfg.ref;
                    layer = new ref(id);
                    if (cfg && cfg.parentid) {
                        var parent = this.getLayer(cfg.parentid);
                        this.addLayerToContainer(layer, parent);
                    }
                    else {
                        this.addLayerToContainer(layer, this._stage);
                    }
                    layers[id] = layer;
                    if (layer instanceof game.SortedLayer) {
                        this._sortedLayers.push(layer);
                    }
                }
                return layer;
            };
            GameEngine.prototype.addLayerToContainer = function (layer, container) {
                var children = container.$children;
                var id = layer.id;
                var i = 0;
                for (var len = children.length; i < len; i++) {
                    var child = children[i];
                    if (child instanceof game.GameLayer) {
                        var childLayer = child;
                        if (childLayer.id > id) {
                            break;
                        }
                    }
                }
                container.addChildAt(layer, i);
            };
            /**
             * 初始化默认添加的层
             */
            GameEngine.prototype.initLayers = function () {
                // [GameLayerID.Tip,GameLayerID.TopUI, GameLayerID.PopUI, GameLayerID.BaseUI, GameLayerID.UI].forEach(ui => {
                //     let layer = this.getLayer(ui);
                //     layer.scaleX = layer.scaleY = 0.75;
                // })
                this.getLayer(9999 /* Out */);
                this.getLayer(9000 /* Tip */);
                this.getLayer(8900 /* TopUI */);
                this.getLayer(8700 /* PopUI */);
                this.getLayer(8100 /* BaseUI */);
                this.getLayer(8000 /* UI */);
                this.getLayer(1000 /* Game */);
                this._gameScene = this.getLayer(1700 /* GameScene */);
                this.getLayer(1790 /* CeilEffect */);
                this.getLayer(1780 /* SortedUI */);
                this.getLayer(1770 /* GameEffect */);
                this.getLayer(1760 /* Sorted */);
                this.getLayer(1750 /* Bottom */);
                this.getLayer(1740 /* BottomEffect */);
                // this._background = <TileMapLayer>this.getLayer(GameLayerID.Background);
                this.getLayer(1710 /* Mini */);
            };
            /**
             * 进入新地图
             */
            // public enterMap(map: MapInfo) {
            //     //先清理场景中的元素
            //     this.clearMap();
            //     this._currentMap = map;
            //     this._background.currentMap = map;
            //     this.initMap();
            //     if (this.camera) {
            //         this.camera.setMaxSize(map.width, map.height);
            //     }
            // }
            /**
             * 清理地图
             */
            GameEngine.prototype.clearMap = function () {
                // 清理底图
                // this._background.removeChildren();
            };
            /**
             * 初始化地图
             */
            GameEngine.prototype.initMap = function () {
                // let map = this._currentMap;
                // let uri = map.resPath 
                // let url = MapInfo.MAP_PATH + uri + "/mini.jpg";
                // this._background.setMini();
                //TODO 加载小地图，渲染到Background层
                this.render();
            };
            /**
             * 渲染
             */
            GameEngine.prototype.render = function () {
                if (GameEngine._sortDirty) {
                    for (var _i = 0, _a = this._sortedLayers; _i < _a.length; _i++) {
                        var sortedLayer = _a[_i];
                        sortedLayer.sort();
                    }
                    GameEngine._sortDirty = false;
                }
                // let camera = this.camera;
                // if (camera.changed) {
                //     let rect = camera.rect;
                //     this._gameScene.scrollRect = this.transSceneRect(rect);
                //     //渲染地图底图
                //     this._background.setRect(rect);
                //     this._viewRect = rect;
                //     camera.change();
                // }
            };
            /**
             * 启动时调用
             */
            GameEngine.prototype.awake = function () {
            };
            /**
             *
             */
            GameEngine.prototype.sleep = function () {
            };
            return GameEngine;
        }(egret.EventDispatcher));
        game.GameEngine = GameEngine;
        __reflect(GameEngine.prototype, "shao.game.GameEngine");
        /**
         * 层级配置
         */
        var LayerConfig = (function () {
            function LayerConfig(id, parentid, ref) {
                if (parentid === void 0) { parentid = 0; }
                this.id = id;
                this.parentid = parentid;
                this.ref = ref || game.GameLayer;
                layerConfigs[id] = this;
            }
            return LayerConfig;
        }());
        __reflect(LayerConfig.prototype, "LayerConfig");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=GameEngine.js.map