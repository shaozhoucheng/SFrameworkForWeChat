var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var GlowTween = (function (_super) {
        __extends(GlowTween, _super);
        function GlowTween(target, props, pluginData, manager, cyclic) {
            if (cyclic === void 0) { cyclic = true; }
            var _this = _super.call(this, target, props, pluginData, manager) || this;
            _this._cyclic = cyclic;
            return _this;
            // if(!this._filter)
        }
        return GlowTween;
    }(shao.Tween));
    shao.GlowTween = GlowTween;
    __reflect(GlowTween.prototype, "shao.GlowTween");
})(shao || (shao = {}));
//# sourceMappingURL=GlowTween.js.map