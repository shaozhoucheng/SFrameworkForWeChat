var shao;
(function (shao) {
    /**
     * 动画的全局对象
     * @author
     *
     */
    shao.Global = (function () {
        var _callLater;
        var _tweenManager;
        /**
         *  当前这一帧的时间
         */
        var _now = 0;
        /**
         * 按照帧，应该走的时间
         * 每帧根据帧率加固定时间
         * 用于处理逐帧同步用
         */
        var _frameNow = 0;
        var _version = "";
        var _reConnect = true;
        var _dataParsed = false;
        return {
            initTick: initTick, callLater: callLater, clearCallLater: clearCallLater, getTween: getTween, removeTween: removeTween, setVersion: setVersion, setConnect: setConnect, setDataParsed: setDataParsed,
            get tweenManager() {
                return _tweenManager || (_tweenManager = new shao.TweenManager());
            },
            /**
             *  当前这一帧的时间
             */
            get now() {
                return _now;
            },
            /**
             * 按照帧，应该走的时间
             * 每帧根据帧率加固定时间
             * 用于处理逐帧同步用
             */
            get frameNow() {
                return _frameNow;
            },
            /**
             *  版本管理
             */
            get version() {
                // console.log("version is " + _version);
                return _version;
            },
            get connect() {
                return _reConnect;
            },
            get dataParesd() {
                return _dataParsed;
            }
        };
        function initTick() {
            var _this = this;
            var ticker = egret.ticker;
            var render = ticker.render;
            var delta = 1000 / 30;
            var callLater = _callLater;
            _callLater = new shao.CallLater();
            _tweenManager || (_tweenManager = new shao.TweenManager());
            ticker.render = function () {
                var now = Date.now();
                var old = _this.now;
                if (true) {
                    _now = now;
                    _frameNow += delta;
                    _callLater.tick(now);
                    render.call(ticker, true, now - old);
                    _tweenManager.tick(now - old);
                }
                else {
                    try {
                        _now = now;
                        _frameNow += delta;
                        _callLater.tick(now);
                        render.call(ticker);
                        _tweenManager.tick(now - old);
                    }
                    catch (e) {
                        var msg = e.message;
                        if (msg) {
                            shao.ReportError(msg);
                        }
                    }
                }
            };
        }
        function setVersion(value) {
            return _version = value;
        }
        function setConnect(value) {
            return _reConnect = value;
        }
        function setDataParsed() {
            return _dataParsed = true;
        }
        /**
         * 延迟执行
         *
         * @static
         * @param {Function} callback (description)
         * @param {number} [time] (description)
         * @param {*} [thisObj] (description)
         * @param args (description)
         */
        function callLater(callback, time, thisObj) {
            var args = [];
            for (var _i = 3; _i < arguments.length; _i++) {
                args[_i - 3] = arguments[_i];
            }
            return _callLater.callLater.apply(_callLater, [callback, shao.Global.now, time, thisObj].concat(args));
        }
        /**
         * 清理延迟
         *
         * @static
         * @param {Function} callback (description)
         * @param {*} [thisObj] (description)
         * @returns (description)
         */
        function clearCallLater(callback, thisObj) {
            return _callLater.clearCallLater(callback, thisObj);
        }
        /**
         * 获取Tween
         *
         * @static
         * @param {*} target 要对那个对象做Tween处理
         * @param {*} props Tween的附加属性 (如： `{loop:true, paused:true}`).
         * All properties default to `false`. Supported props are:
         * <UL>
         *    <LI> loop: sets the loop property on this tween.</LI>
         *    <LI> useTicks: uses ticks for all durations instead of milliseconds.</LI>
         *    <LI> ignoreGlobalPause: sets the {{#crossLink "Tween/ignoreGlobalPause:property"}}{{/crossLink}} property on
         *    this tween.</LI>
         *    <LI> override: if true, `createjs. this.removeTweens(target)` will be called to remove any other tweens with
         *    the same target.
         *    <LI> paused: indicates whether to start the tween paused.</LI>
         *    <LI> position: indicates the initial position for this tween.</LI>
         *    <LI> onChange: specifies a listener for the {{#crossLink "Tween/change:event"}}{{/crossLink}} event.</LI>
         * </UL>
         * @param {*} pluginData 插件数据
         * @param {boolean} override 是否覆盖
         * @returns {Tween} tween的实例
         */
        function getTween(target, props, pluginData, override) {
            return _tweenManager.get(target, props, pluginData, override);
        }
        function removeTween(target) {
            if (target)
                _tweenManager.removeTweens(target);
        }
    })();
})(shao || (shao = {}));
//# sourceMappingURL=Global.js.map