var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    /**
     * 资源管理器
     */
    var ResourceManager = (function () {
        function ResourceManager() {
        }
        /**
         *
         * 获取纹理资源
         * @static
         * @param {string} resID        资源标识
         * @returns {TextureResource}
         */
        ResourceManager.getTextureRes = function (resID) {
            var resources = ResourceManager.resources;
            var res = resources[resID];
            if (res) {
                if (!(res instanceof shao.TextureResource)) {
                    shao.ThrowError("[" + resID + "]\u8D44\u6E90\u6709\u8BEF\uFF0C\u4E0D\u662FTextureResource");
                    res = undefined;
                }
            }
            if (!res) {
                res = new shao.TextureResource();
                res.resID = resID;
                res.url = shao.ConfigUtils.getResUrl(resID, true);
                resources[resID] = res;
            }
            return res;
        };
        /**
         * 获取资源
         */
        ResourceManager.getResource = function (resID) {
            return ResourceManager.resources[resID];
        };
        /**
         * 注册资源
         */
        ResourceManager.regResource = function (resID, res) {
            var resources = ResourceManager.resources;
            if (resID in resources) {
                return resources[resID] === res;
            }
            resources[resID] = res;
            return true;
        };
        //按时间检测资源
        ResourceManager.init = function () {
            var tobeDele = [];
            shao.TimerUtil.addCallback(ResourceManager.CHECK_TIME, function () {
                var expire = shao.Global.now - ResourceManager.DISPOSE_TIME;
                var reses = ResourceManager.resources;
                var i = 0;
                for (var key in reses) {
                    var res = reses[key];
                    if (!res.isStatic && res.lastUseTime < expire) {
                        tobeDele[i++] = key;
                    }
                }
                for (var _i = 0, tobeDele_1 = tobeDele; _i < tobeDele_1.length; _i++) {
                    var key = tobeDele_1[_i];
                    var res = reses[key];
                    if (res) {
                        res.dispose();
                        RES.destroyRes(res.url);
                        delete reses[key];
                    }
                }
                tobeDele.length = 0;
            });
        };
        /**
         * 默认资源检测时间
         */
        ResourceManager.CHECK_TIME = 60000;
        /**
         * 默认销毁时间，1分钟之内资源没有被使用过，直接销毁
         */
        ResourceManager.DISPOSE_TIME = 60000;
        ResourceManager.resources = {};
        return ResourceManager;
    }());
    shao.ResourceManager = ResourceManager;
    __reflect(ResourceManager.prototype, "shao.ResourceManager");
})(shao || (shao = {}));
//# sourceMappingURL=ResourceManager.js.map