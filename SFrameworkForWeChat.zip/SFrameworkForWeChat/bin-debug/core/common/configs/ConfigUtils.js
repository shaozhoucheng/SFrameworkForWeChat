var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    /**
     * 配置工具
     * @author builder
     * @export
     * @class ConfigUtils
     */
    var ConfigUtils = (function () {
        function ConfigUtils() {
        }
        /**
         * 设置配置数据
         *
         * @static
         * @param {JConfig} data 配置
         */
        ConfigUtils.setData = function (data) {
            this._data = data;
        };
        /**
         * 获取资源完整路径
         *
         * @static
         * @param {string} uri                  路径标识
         * @param {Boolean} [sameDomain=false]  是否为同域，同域的话，资源从resource中获取
         * @returns {string}
         */
        ConfigUtils.getResUrl = function (uri, sameDomain) {
            if (sameDomain) {
                return "resource/remote/" + uri;
            }
            var hash = this._hash;
            if (hash) {
                var ver = hash[uri];
                if (ver) {
                    if (uri.indexOf("?") == -1) {
                        uri = uri + "?" + ver;
                    }
                    else {
                        uri = uri + "&jyver=" + ver;
                    }
                }
            }
            return this.getUrlWithPath(uri, this._data.paths.res);
        };
        /**
         * 通过Path获取完整url
         *
         * @private
         * @static
         * @param {string} uri 路径标识
         * @param {Path} path Path对象
         * @returns
         */
        ConfigUtils.getUrlWithPath = function (uri, path) {
            uri = path.path + uri;
            var prefix = path.iPrefix ? "" : this.getPrefix(uri);
            return prefix + uri;
        };
        ConfigUtils.setPreloadRes = function (uri, name) {
            this._preloadRes[uri] = name;
            // if (uri.indexOf("skin") != -1)
            // {
            //     let index = uri.indexOf("../");
            //     let end = uri.indexOf("?v=");
            //     index = index != -1 ? index + 3 : 0;
            //     if (end>0) {
            //         uri = uri.slice(index, end);
            //     } else {
            //         uri = uri.slice(index);
            //     }
            // }
        };
        ConfigUtils.getPreloadSkinResData = function (uri) {
            var name = this._preloadRes[uri];
            if (name)
                return RES.getRes(name);
            // let index = uri.indexOf("skin");
            // if (index != -1)
            // {
            //     let end = uri.indexOf("?v=");
            //     if (end > 0) uri = uri.slice(index, end);
            //     else uri = uri.slice(index);
            //     let name = this._preloadRes[uri];
            //     if (name) return RES.getRes(name);
            // }
            // return undefined;
        };
        /**
         * 根据资源标识获取网址前缀
         */
        ConfigUtils.getPrefix = function (uri) {
            var prefixes = this._data.prefixes;
            var idx = uri.hash() % prefixes.length;
            return prefixes[idx] || "";
        };
        /**
         * 获取参数
         */
        ConfigUtils.getParam = function (key) {
            return this._data.params[key];
        };
        /**
         * 获取皮肤文件地址
         */
        ConfigUtils.getSkinFile = function (key, fileName) {
            return this.getUrlWithPath(key + "/" + fileName, this._data.paths.skin);
        };
        /**
         * 通过配置中预加载资源map
         */
        ConfigUtils._preloadRes = {};
        return ConfigUtils;
    }());
    shao.ConfigUtils = ConfigUtils;
    __reflect(ConfigUtils.prototype, "shao.ConfigUtils");
    function createObjectFromArray(ref, keys, data) {
        var obj = new ref();
        for (var i = 0, len = keys.length; i < len; i++) {
            var key = keys[i];
            // if (key in obj) { TS -> JS 对象未赋值的属性不会初始化
            if (i in data) {
                obj[key] = data[i];
            }
            // }
        }
        return obj;
    }
    shao.createObjectFromArray = createObjectFromArray;
})(shao || (shao = {}));
//# sourceMappingURL=ConfigUtils.js.map