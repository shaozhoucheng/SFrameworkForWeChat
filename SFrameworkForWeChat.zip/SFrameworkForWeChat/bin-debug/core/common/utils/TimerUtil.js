var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var _timeobj = {};
function tick(timer) {
    timer.map.forEach(function (args, callback) {
        if (callback)
            callback.apply(undefined, args);
    });
    //  timer.map.forEach(( callback, args )=>{
    //     callback.apply(undefined, args);
    // })
}
function getInterval(time) {
    return Math.ceil(time / 30) * 30;
}
/**
 * GTimer
 */
var GTimer2 = (function () {
    function GTimer2() {
        this.map = new shao.MapDict();
    }
    return GTimer2;
}());
__reflect(GTimer2.prototype, "GTimer2");
var shao;
(function (shao) {
    var TimerUtil = (function () {
        function TimerUtil() {
        }
        /**
         *
         * 注册回调
         * @static
         * @param {number} time 回调的间隔时间，间隔时间会处理成30的倍数，向上取整，如 设置1ms，实际间隔为30ms，32ms，实际间隔会使用60ms
         * @param {Function} callback 回调函数，没有加this指针是因为做移除回调的操作会比较繁琐，如果函数中需要使用this，请通过箭头表达式()=>{}，或者将this放arg中传入
         * @param {any} args
         */
        TimerUtil.addCallback = function (time, callback) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            time = getInterval(time);
            var timer = _timeobj[time];
            if (!timer) {
                timer = new GTimer2();
                timer.tid = setInterval(tick, time, timer);
                _timeobj[time] = timer;
            }
            timer.map.set(callback, args);
        };
        /**
         * 移除回调
         */
        TimerUtil.removeCallback = function (time, callback) {
            time = getInterval(time);
            var timer = _timeobj[time];
            if (timer) {
                var map = timer.map;
                map.delete(callback);
                if (!map.size) {
                    clearInterval(timer.tid);
                    delete _timeobj[time];
                }
            }
        };
        return TimerUtil;
    }());
    shao.TimerUtil = TimerUtil;
    __reflect(TimerUtil.prototype, "shao.TimerUtil");
})(shao || (shao = {}));
//# sourceMappingURL=TimerUtil.js.map