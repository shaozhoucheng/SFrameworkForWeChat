var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    /**
     *
     * 纹理资源
     * @export
     * @class TextureResource
     * @implements {IResource}
     */
    var TextureResource = (function () {
        function TextureResource() {
            /**
             *
             * 绑定的对象列表
             * @private
             * @type {Bitmap[]}
             */
            this._list = [];
        }
        Object.defineProperty(TextureResource.prototype, "isStatic", {
            /**
             *
             * 是否为静态不销毁的资源
             * @type {boolean}
             */
            get: function () {
                return this._list.length > 0;
            },
            enumerable: true,
            configurable: true
        });
        /**
         *
         * 绑定一个目标
         * @param {Bitmap} target
         */
        TextureResource.prototype.bind = function (bmp) {
            if (this._tex) {
                bmp.texture = this._tex;
            }
            this._list.pushOnce(bmp);
            this.lastUseTime = shao.Global.now;
        };
        /**
         *
         * 解除目标的绑定
         * @param {Bitmap} target
         */
        TextureResource.prototype.loose = function (bmp) {
            this._list.remove(bmp);
            this.lastUseTime = shao.Global.now;
        };
        TextureResource.prototype.load = function () {
            RES.getResByUrl(this.url, this.loadComplete, this, RES.ResourceItem.TYPE_IMAGE);
        };
        /**
         * 资源加载完成
         */
        TextureResource.prototype.loadComplete = function (res, key) {
            if (key == this.url) {
                this._tex = res;
                if (this._list && this._list.length) {
                    for (var _i = 0, _a = this._list; _i < _a.length; _i++) {
                        var bmp = _a[_i];
                        if (!bmp)
                            continue;
                        bmp.texture = res;
                        bmp.dispatchEventWith(3 /* BMP_LOAD_COMPLETE */);
                    }
                }
            }
        };
        /**
         * 销毁资源
         */
        TextureResource.prototype.dispose = function () {
            if (this._tex) {
                this._tex.dispose();
                this._tex = undefined;
            }
            this._list.forEach(function (bmp) {
                if (bmp instanceof shao.sui.Image) {
                    bmp.dispose();
                }
            });
            this._list.length = 0;
        };
        return TextureResource;
    }());
    shao.TextureResource = TextureResource;
    __reflect(TextureResource.prototype, "shao.TextureResource", ["shao.IResource"]);
})(shao || (shao = {}));
//# sourceMappingURL=TextureResource.js.map