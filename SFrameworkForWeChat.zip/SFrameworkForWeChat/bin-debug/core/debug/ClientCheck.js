var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    /**
     * 客户端检测
     * @author builder
     *
     */
    var ClientCheck = (function () {
        function ClientCheck() {
        }
        /**
         * 是否做客户端检查
         */
        ClientCheck.isClientCheck = true;
        return ClientCheck;
    }());
    shao.ClientCheck = ClientCheck;
    __reflect(ClientCheck.prototype, "shao.ClientCheck");
})(shao || (shao = {}));
//# sourceMappingURL=ClientCheck.js.map