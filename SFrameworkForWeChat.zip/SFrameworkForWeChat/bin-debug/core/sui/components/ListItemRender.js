var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var sui;
    (function (sui) {
        var ListItemRender = (function (_super) {
            __extends(ListItemRender, _super);
            function ListItemRender() {
                var _this = _super.call(this) || this;
                _this._defaultWidth = 5;
                _this._defalutHeight = 5;
                _this._viewChange = false;
                _this._oldWidth = -1;
                _this._oldHeight = -1;
                _this.inited = false;
                _this.index = -1;
                _this.touchEnabled = true;
                _this.on(egret.TouchEvent.TOUCH_TAP, _this.onTouchTap, _this);
                _this.on(egret.Event.ADDED_TO_STAGE, _this.checkawake, _this);
                _this.on(egret.Event.REMOVED_FROM_STAGE, _this.checksleep, _this);
                return _this;
            }
            /**
             * 子类重写
             * 初始化组件
             * 一定要super调一下
             */
            ListItemRender.prototype.bindComponent = function () {
                this.inited = true;
                // if (!this._skin) {
                //     if (this.skinlib && this.skinClass) {
                //         this.skin = SuiResManager.getInstance().createDisplayObject(this.skinlib, this.skinClass);
                //     }
                // } else {
                //     if (!this.contains(this._skin)) {
                //         this.addChildAt(this._skin, 0);
                //     }
                // }
                if (!this.contains(this._skin)) {
                    this.addChildAt(this._skin, 0);
                }
            };
            ListItemRender.prototype.checkawake = function (e) {
                this.awake();
            };
            /**
             * 子类重写
             * 皮肤添加到舞台时调用
             */
            ListItemRender.prototype.awake = function () {
            };
            ListItemRender.prototype.checksleep = function (e) {
                this.sleep();
            };
            /**
             * 子类重写
             * 皮肤从舞台移除时调用
             */
            ListItemRender.prototype.sleep = function () {
            };
            ListItemRender.prototype.onTouchTap = function (e) {
                this.dispatchEventWith(-1001 /* ITEM_TOUCH_TAP */);
            };
            ListItemRender.prototype.setData = function (value) {
                this._data = value;
                if (!this.inited) {
                    this.bindComponent();
                    this.inited = true;
                }
            };
            ListItemRender.prototype.getData = function () {
                return this._data;
            };
            Object.defineProperty(ListItemRender.prototype, "skinTemplete", {
                /**
                 * 设置已定位好的皮肤
                 * (description)
                 */
                set: function (value) {
                    this._skinTemplete = value;
                    var parent = value.parent;
                    this.x = value.x;
                    this.y = value.y;
                    this.skin = value;
                    this._skin.x = 0;
                    this._skin.y = 0;
                    parent.addChild(this);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListItemRender.prototype, "skin", {
                get: function () {
                    return this._skin;
                },
                set: function (value) {
                    this._skin = value;
                },
                enumerable: true,
                configurable: true
            });
            /**
             * 根据数据处理视图
             *
             * 子类重写
             */
            ListItemRender.prototype.handleView = function () {
                if (this._viewChange == false) {
                    this._viewChange = true;
                    this.checkViewSize();
                }
            };
            /**
             * force为true时无条件派发一次事件，通知更新坐标
             *
             * @protected
             * @ param {boolean} [force=false] (description)
             */
            ListItemRender.prototype.checkViewSize = function (force) {
                if (force === void 0) { force = false; }
                this._viewChange = false;
                if (force) {
                    this.dispatchEventWith(egret.Event.RESIZE);
                }
                else {
                    if (this._oldHeight != this.height || this._oldWidth != this.width) {
                        this.dispatchEventWith(egret.Event.RESIZE);
                    }
                }
                this._oldHeight = this.height;
                this._oldWidth = this.width;
            };
            Object.defineProperty(ListItemRender.prototype, "renderView", {
                /**\
                 *
                 * 获取视图
                 * @readonly
                 */
                get: function () {
                    return this;
                },
                enumerable: true,
                configurable: true
            });
            ListItemRender.prototype.setChooseState = function (value) {
                if (this._chooseState != value) {
                    this._chooseState = value;
                }
                this.dispatchEventWith(-1000 /* CHOOSE_STATE_CHANGE */);
            };
            ListItemRender.prototype.getChooseState = function () {
                return this._chooseState;
            };
            /**
             * 子类重写
             * 销毁组件
             */
            ListItemRender.prototype.dispose = function () {
                this.off(egret.TouchEvent.TOUCH_TAP, this.onTouchTap, this);
                this.off(egret.Event.ADDED_TO_STAGE, this.checkawake, this);
                this.off(egret.Event.REMOVED_FROM_STAGE, this.checksleep, this);
            };
            ListItemRender.prototype.refreshData = function () {
                this.setData(this._data);
            };
            ListItemRender.prototype.onRecycle = function () {
                this._data = undefined;
            };
            return ListItemRender;
        }(egret.Sprite));
        sui.ListItemRender = ListItemRender;
        __reflect(ListItemRender.prototype, "shao.sui.ListItemRender", ["shao.sui.BaseListItemRender"]);
    })(sui = shao.sui || (shao.sui = {}));
})(shao || (shao = {}));
//# sourceMappingURL=ListItemRender.js.map