var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var sui;
    (function (sui) {
        var Event = egret.Event;
        /**
         * 图片
         * 外部加载
         * @pb
         *S
         */
        var Image = (function (_super) {
            __extends(Image, _super);
            function Image() {
                var _this = _super.call(this) || this;
                _this.isLoaded = false;
                _this.on(Event.ADDED_TO_STAGE, _this.addedToStage, _this);
                _this.on(Event.REMOVED_FROM_STAGE, _this.removedFromStage, _this);
                _this.on(3 /* BMP_LOAD_COMPLETE */, _this.onBmpComplete, _this);
                return _this;
            }
            Image.prototype.onBmpComplete = function () {
                this.off(3 /* BMP_LOAD_COMPLETE */, this.onBmpComplete, this);
                this.isLoaded = true;
                if (this.texture) {
                    if (!this.width)
                        this.width = this.texture.$getTextureWidth();
                    if (!this.height)
                        this.height = this.texture.$getTextureHeight();
                }
            };
            Image.prototype.addedToStage = function () {
                if (this.uri) {
                    var res = shao.ResourceManager.getTextureRes(this.uri);
                    if (res) {
                        res.bind(this);
                        res.load();
                    }
                }
            };
            Image.prototype.removedFromStage = function () {
                if (this.uri) {
                    var res = shao.ResourceManager.getResource(this.uri);
                    if (res) {
                        res.loose(this);
                    }
                }
            };
            Object.defineProperty(Image.prototype, "source", {
                /**
                 * 设置资源标识
                 */
                set: function (value) {
                    if (this.uri == value)
                        return;
                    if (this.uri) {
                        this.removedFromStage();
                    }
                    this.uri = value;
                    if (value) {
                        if (this.stage) {
                            this.addedToStage();
                        }
                    }
                    else {
                        this.texture = undefined;
                    }
                },
                enumerable: true,
                configurable: true
            });
            /**
             * 销毁图片
             */
            Image.prototype.dispose = function () {
                this.removedFromStage();
                this.off(Event.ADDED_TO_STAGE, this.addedToStage, this);
                this.off(Event.REMOVED_FROM_STAGE, this.removedFromStage, this);
                this.off(3 /* BMP_LOAD_COMPLETE */, this.onBmpComplete, this);
                shao.removeDisplay(this);
            };
            /**
             * 设置size
             *
             * @param {egret.Rectangle} r
             *
             * @memberOf Image
             */
            Image.prototype.setRect = function (r) {
                this.x = r.x;
                this.y = r.y;
                this.width = r.width;
                this.height = r.height;
            };
            return Image;
        }(egret.Bitmap));
        sui.Image = Image;
        __reflect(Image.prototype, "shao.sui.Image");
    })(sui = shao.sui || (shao.sui = {}));
})(shao || (shao = {}));
//# sourceMappingURL=Image.js.map