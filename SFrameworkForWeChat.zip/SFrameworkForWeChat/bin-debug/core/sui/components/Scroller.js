var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var sui;
    (function (sui) {
        var Scroller = (function (_super) {
            __extends(Scroller, _super);
            function Scroller() {
                var _this = _super.call(this) || this;
                _this._scrollType = 0;
                /**鼠标每移动1像素，元件移动的像素 */
                _this.globalspeed = 3;
                /**最小的滑动速度，当前值低于此值后不再滚动 */
                _this.minEndSpeed = 0.0001;
                /**速度递减速率 */
                _this.blockSpeed = 0.98;
                // protected _useScrollBar: boolean;
                _this._deriction = 1;
                _this._moveSpeed = 0;
                return _this;
            }
            Object.defineProperty(Scroller.prototype, "scrollType", {
                /**滚动条方式 0：垂直，1：水平 defalut:0*/
                get: function () {
                    return this._scrollType;
                },
                /**滚动条方式 0：垂直，1：水平 defalut:0*/
                set: function (value) {
                    this._scrollType = value;
                    this.addPropertyListener();
                    // this.checkScrollBarView();
                },
                enumerable: true,
                configurable: true
            });
            // protected checkScrollBarView() {
            //     if (!this._useScrollBar || !this._content) return;
            //     this._scrollbar.scrollType = this._scrollType;
            //     let rect: egret.Rectangle = this._content.scrollRect;
            //     if (this._scrollType == 0) {
            //         this._scrollbar.bgSize = rect.height;
            //         this._scrollbar.y = this._content.y;
            //     } else {
            //         this._scrollbar.bgSize = rect.width;
            //         this._scrollbar.x = this._content.x;
            //     }
            // }
            // protected onScrollBarAdded(e?: egret.Event) {
            //     if (this.alwaysShowBar) {
            //         this._scrollbar.alpha = 1;
            //     } else {
            //         this._scrollbar.alpha = 0;
            //     }
            // }
            /**
             * 绑定目标与滚动条
             *
             * @ content (需要滚动的目标)
             * @ scrollRect (显示的区域大小)
             * @ scrollbar (可选，如果不想显示滚动条可不传)
             */
            Scroller.prototype.bindObj = function (content, scrollRect /*, scrollbar?: ScrollBar*/) {
                this._content = content;
                if ("scroller" in content) {
                    content["scroller"] = this;
                }
                content.touchEnabled = true;
                content.scrollRect = scrollRect;
                content.on(egret.TouchEvent.TOUCH_BEGIN, this.onTargetTouchBegin, this);
                // if (scrollbar) {
                //     this._scrollbar = scrollbar;
                //     this._useScrollBar = true;
                //     this.checkScrollBarView();
                //     this.scaleBar();
                //     if (scrollbar.stage) {
                //         this.onScrollBarAdded();
                //     } else {
                //         scrollbar.on(egret.Event.ADDED_TO_STAGE, this.onScrollBarAdded, this);
                //     }
                // } else {
                //     this._useScrollBar = false;
                // }
                this.addPropertyListener();
                this.checkScrollEnd();
                this.scrollToHead();
            };
            Scroller.prototype.removeListener = function () {
                this._content.off(egret.TouchEvent.TOUCH_BEGIN, this.onTargetTouchBegin, this);
            };
            Scroller.prototype.addPropertyListener = function () {
                if (!this._content) {
                    return;
                }
                if (this._scrollType == 0) {
                    sui.Watcher.watch(this._content, ["height"], this.contentSizeChange, this);
                }
                else {
                    sui.Watcher.watch(this._content, ["width"], this.contentSizeChange, this);
                }
            };
            Scroller.prototype.contentSizeChange = function (value) {
                // if (this._useScrollBar) {
                //     this.scaleBar();
                // } else {
                //     this.checkScrollEnd();
                // }
                this.checkScrollEnd();
            };
            Scroller.prototype.onTargetTouchBegin = function (e) {
                if (this._scrollType == 0) {
                    if (this._content.height < this._content.scrollRect.height) {
                        return;
                    }
                }
                else {
                    if (this._content.width < this._content.scrollRect.width) {
                        return;
                    }
                }
                this._lastMoveTime = shao.Global.now;
                if (this._scrollType == 0) {
                    this._lastTargetPos = e.stageY;
                }
                else {
                    this._lastTargetPos = e.stageX;
                }
                this._content.stage.on(egret.TouchEvent.TOUCH_MOVE, this.moveOnContent, this);
                this._content.on(egret.TouchEvent.TOUCH_END, this.endTouchContent, this);
                this._content.on(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.endTouchContent, this);
                // if (this._useScrollBar) {
                //     if (!this.alwaysShowBar) {
                //         let tween: lingyu.Tween = Global.getTween(this._scrollbar, undefined, undefined, true);
                //         tween.to({ alpha: 1 }, 500);
                //     }
                // }
            };
            Scroller.prototype.moveOnContent = function (e) {
                var currentPos;
                if (this._scrollType == 0) {
                    currentPos = e.stageY;
                }
                else {
                    currentPos = e.stageX;
                }
                var sub = currentPos - this._lastTargetPos;
                this._deriction = sub > 0 ? 1 : -1;
                sub = Math.abs(sub);
                var now = shao.Global.now;
                var subTime = now - this._lastMoveTime;
                this._lastMoveTime = now;
                this._lastTargetPos = currentPos;
                this._moveSpeed = subTime > 0 ? sub / subTime : 0;
                sub = sub * this.globalspeed * this._deriction;
                this.doScrollContent(sub);
            };
            Scroller.prototype.onEnterFrame = function (e) {
                if (this._moveSpeed == 0) {
                    this._content.off(egret.Event.ENTER_FRAME, this.onEnterFrame, this);
                    // if (this._useScrollBar) {
                    //     if (!this.alwaysShowBar) {
                    //         let tween: lingyu.Tween = Global.getTween(this._scrollbar, undefined, undefined, true);
                    //         tween.to({ alpha: 0 }, 1000);
                    //     }
                    // }
                    return;
                }
                var now = shao.Global.now;
                var subTime = now - this._lastFrameTime;
                var sub = this._moveSpeed * this._deriction * subTime * this.globalspeed;
                this.doScrollContent(sub);
                this._lastFrameTime = now;
                this._moveSpeed *= this.blockSpeed;
                if (this._moveSpeed < this.minEndSpeed) {
                    this._moveSpeed = 0;
                }
            };
            Scroller.prototype.endTouchContent = function (e) {
                if (this._content.stage) {
                    this._content.stage.off(egret.TouchEvent.TOUCH_MOVE, this.moveOnContent, this);
                }
                this._content.off(egret.TouchEvent.TOUCH_END, this.endTouchContent, this);
                this._content.off(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.endTouchContent, this);
                var now = shao.Global.now;
                if (now - this._lastMoveTime < 150) {
                    this._content.on(egret.Event.ENTER_FRAME, this.onEnterFrame, this);
                    this._lastFrameTime = this._lastMoveTime;
                }
                else {
                    // if (this._useScrollBar) {
                    //     if (!this.alwaysShowBar) {
                    //         let tween: lingyu.Tween = Global.getTween(this._scrollbar, undefined, undefined, true);
                    //         tween.to({ alpha: 0 }, 1000);
                    //     }
                    // }
                }
            };
            /**
             * 执行滚动
             *
             * @ sub (滚动的距离)
             */
            Scroller.prototype.doScrollContent = function (sub) {
                var rect = this._content.scrollRect;
                var oldx = rect.x;
                var oldy = rect.y;
                if (this._scrollType == 0) {
                    rect.y -= sub;
                    if (rect.y <= 0) {
                        rect.y = 0;
                        this._moveSpeed = 0;
                    }
                    if (rect.y >= this._scrollEnd) {
                        rect.y = this._scrollEnd;
                        this._moveSpeed = 0;
                    }
                }
                else {
                    rect.x -= sub;
                    if (rect.x <= 0) {
                        rect.x = 0;
                        this._moveSpeed = 0;
                    }
                    if (rect.x >= this._scrollEnd) {
                        rect.x = this._scrollEnd;
                        this._moveSpeed = 0;
                    }
                }
                this._content.scrollRect = rect;
                if (oldx != rect.x || oldy != rect.y) {
                    this._content.dispatchEventWith(-1051 /* SCROLL_POSITION_CHANGE */);
                }
                // this.doMoveScrollBar(sub);
            };
            // public doMoveScrollBar(sub: number) {
            //     if (!this._useScrollBar) {
            //         return;
            //     }
            //     let barPos: number;
            //     let subPos: number = sub / this._piexlDistance;
            //     if (this._scrollType == 0) {
            //         barPos = this._scrollbar.bar.y;
            //     }
            //     else {
            //         barPos = this._scrollbar.bar.x;
            //     }
            //     barPos = barPos - subPos;
            //     if (barPos <= 0) {
            //         barPos = 0;
            //     }
            //     if (barPos >= this._scrollbar.bgSize - this._scrollbar.barSize) {
            //         barPos = this._scrollbar.bgSize - this._scrollbar.barSize;
            //     }
            //     if (this._scrollType == 0) {
            //         this._scrollbar.bar.y = barPos;
            //     }
            //     else {
            //         this._scrollbar.bar.x = barPos;
            //     }
            // }
            /**
             * 移动到指定位置
             *
             * @ pos (位置)
             */
            Scroller.prototype.scrollTo = function (pos) {
                if (pos <= 0) {
                    this.scrollToHead();
                }
                else if (pos >= this._scrollEnd) {
                    this.scrollToEnd();
                }
                else {
                    var rect = this._content.scrollRect;
                    var curpos = void 0;
                    if (this._scrollType == 0) {
                        curpos = rect.y;
                    }
                    else {
                        curpos = rect.x;
                    }
                    this.doScrollContent(pos - curpos);
                }
            };
            /**移动至头 */
            Scroller.prototype.scrollToHead = function () {
                if (this._moveSpeed > 0) {
                    this._moveSpeed = 0;
                    this._content.off(egret.Event.ENTER_FRAME, this.onEnterFrame, this);
                }
                var rect = this._content.scrollRect;
                if (this._scrollType == 0) {
                    rect.y = 0;
                    // if (this._useScrollBar) {
                    //     this._scrollbar.bar.y = 0;
                    // }
                }
                else {
                    rect.x = 0;
                    // if (this._useScrollBar) {
                    //     this._scrollbar.bar.x = 0;
                    // }
                }
                this._content.scrollRect = rect;
            };
            /**移动至尾 */
            Scroller.prototype.scrollToEnd = function () {
                var rect = this._content.scrollRect;
                if (this._scrollType == 0) {
                    rect.y = this._scrollEnd;
                    // if (this._useScrollBar) {
                    //     this._scrollbar.bar.y = this._scrollbar.bgSize - this._scrollbar.barSize;
                    // }
                }
                else {
                    rect.x = this._scrollEnd;
                    // if (this._useScrollBar) {
                    //     this._scrollbar.bar.x = this._scrollbar.bgSize - this._scrollbar.barSize;
                    // }
                }
                this._content.scrollRect = rect;
            };
            // protected scaleBar() {
            //     let scale: number;
            //     let contentSize: number;
            //     if (this._scrollType == 0) {
            //         contentSize = this._content.height;
            //     }
            //     else {
            //         contentSize = this._content.width;
            //     }
            //     scale = this._scrollbar.bgSize / contentSize;
            //     if (scale >= 1) {
            //         scale = 1;
            //     }
            //     this._scrollbar.barSize = this._scrollbar.bgSize * scale;
            //     this.checkScrollEnd();
            //     this._piexlDistance = contentSize / this._scrollbar.bgSize;
            //     this.checkAndResetBarPos();
            // }
            Scroller.prototype.checkScrollEnd = function () {
                if (!this._content) {
                    return;
                }
                var contentSize;
                var rect = this._content.scrollRect;
                var scrollSize;
                if (this._scrollType == 0) {
                    contentSize = this._content.height;
                    scrollSize = rect.height;
                }
                else {
                    contentSize = this._content.width;
                    scrollSize = rect.width;
                }
                this._scrollEnd = Math.round(Math.max(contentSize - scrollSize, 0));
            };
            return Scroller;
        }(egret.EventDispatcher));
        sui.Scroller = Scroller;
        __reflect(Scroller.prototype, "shao.sui.Scroller");
    })(sui = shao.sui || (shao.sui = {}));
})(shao || (shao = {}));
//# sourceMappingURL=Scroller.js.map