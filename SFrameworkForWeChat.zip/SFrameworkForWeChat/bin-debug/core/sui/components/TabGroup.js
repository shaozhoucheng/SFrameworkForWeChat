var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var sui;
    (function (sui) {
        var TabGroup = (function (_super) {
            __extends(TabGroup, _super);
            // private container: egret.DisplayObjectContainer;
            function TabGroup() {
                var _this = _super.call(this) || this;
                _this._selectedIndex = -1;
                _this._list = [];
                // this.container = container;
                _this._checklist = {};
                return _this;
                // this._displaylist = {};
            }
            // private _displaylist: { [index: number]: egret.DisplayObject };
            /**
            * 添加单个组件
            *
            * @param {IGroupItem} item
            */
            TabGroup.prototype.addItem = function (item, check) {
                if (item) {
                    this._list.pushOnce(item);
                    var index = this._list.indexOf(item);
                    if (check)
                        this._checklist[index] = check;
                    // if(display)
                    //     this._displaylist[index] = display;
                    item.on(egret.TouchEvent.TOUCH_TAP, this.touchHandler, this);
                }
            };
            TabGroup.prototype.touchHandler = function (e) {
                var item = e.target;
                var idx = this._list.indexOf(item);
                var fun = this._checklist[idx];
                if (fun && !fun())
                    return;
                this.selectedIndex = idx;
            };
            /**
            * 移除单个组件
            *
            * @param {IGroupItem} item
            */
            TabGroup.prototype.removeItem = function (item) {
                if (item) {
                    var index = this._list.indexOf(item);
                    // let display = this._displaylist[index];
                    // if(display) removeDisplay(display);
                    this._list.remove(item);
                    item.off(egret.TouchEvent.TOUCH_TAP, this.touchHandler, this);
                }
            };
            Object.defineProperty(TabGroup.prototype, "selectedItem", {
                get: function () {
                    return this._selectedItem;
                },
                /**
                 * 设置选中组件
                 */
                set: function (item) {
                    var _selectedItem = this._selectedItem;
                    if (_selectedItem == item)
                        return;
                    if (_selectedItem) {
                        if ("selected" in _selectedItem) {
                            _selectedItem["selected"] = false;
                        }
                        // let index = this._list.indexOf(item);
                        // let display = this._displaylist[index];
                        // if (display) {
                        //     removeDisplay(display);
                        // }
                    }
                    this._selectedItem = item;
                    _selectedItem = this._selectedItem;
                    if (_selectedItem) {
                        if (!~this._list.indexOf(_selectedItem)) {
                            shao.ThrowError("Group 设置的组件未添加到该组");
                        }
                        if ("selected" in _selectedItem) {
                            _selectedItem["selected"] = true;
                        }
                        // let index = this._list.indexOf(item);
                        // let display = this._displaylist[index];
                        // if (display && this.container) {
                        //     this.container.addChild(display);
                        // }
                    }
                    this.dispatchEventWith(-1020 /* GROUP_CHANGE */);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TabGroup.prototype, "selectedIndex", {
                get: function () {
                    return this._selectedIndex;
                },
                /**
                * 设置选中索引
                */
                set: function (idx) {
                    this._selectedIndex = idx;
                    if (idx >= 0) {
                        var item = this._list[idx];
                        this.selectedItem = item;
                        item.selected = true;
                    }
                    else {
                        this.selectedItem = undefined;
                    }
                },
                enumerable: true,
                configurable: true
            });
            return TabGroup;
        }(egret.EventDispatcher));
        sui.TabGroup = TabGroup;
        __reflect(TabGroup.prototype, "shao.sui.TabGroup");
    })(sui = shao.sui || (shao.sui = {}));
})(shao || (shao = {}));
//# sourceMappingURL=TabGroup.js.map