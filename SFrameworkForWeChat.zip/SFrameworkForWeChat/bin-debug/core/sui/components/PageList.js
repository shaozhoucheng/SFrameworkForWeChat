var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var sui;
    (function (sui) {
        var PageList = (function (_super) {
            __extends(PageList, _super);
            /**
             * Creates an instance of NewPageList.
             *
             * @param {{ new (): R }} renderClass   必须，需要加载的单元容器对象
             * @param {number} columnWidth  必须，单元之间的宽度
             * @param {number} rowHeight  必须，单元之间的高度
             * @param {boolean} [train=true]  排列方式，true 为优先x排列再向下延伸,false 横排 为优先y排列再向右延伸 ，默认为 true
             * @param {number} [columnCount=1] 每行\列最多排列数，默认为 1
             *
             * @memberOf NewPageList
             */
            function PageList(renderClass, columnWidth, rowHeight, train, columnCount) {
                if (train === void 0) { train = true; }
                if (columnCount === void 0) { columnCount = 1; }
                var _this = _super.call(this) || this;
                _this._selectedIndex = -1;
                _this.isNeedMoveToSelect = false;
                /**触摸中 */
                _this._isInTouch = false;
                _this.touchEnabled = false;
                _this._renderClass = renderClass;
                _this._columnWidth = columnWidth;
                _this._rowHeight = rowHeight;
                _this._train = train;
                _this._columnCount = columnCount;
                _this.scroller = null;
                _this._renderRect = new egret.Rectangle(0, 0, columnWidth, rowHeight);
                _this._renderList = [];
                _this._waitUpdateIndexs = [];
                _this.on(-1051 /* SCROLL_POSITION_CHANGE */, _this.scrollPositionChange, _this);
                _this.on(egret.TouchEvent.TOUCH_BEGIN, _this.onTouchBegin, _this);
                _this.on(egret.TouchEvent.TOUCH_END, _this.onTouchEnd, _this);
                _this.on(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, _this.onTouchEnd, _this);
                return _this;
            }
            Object.defineProperty(PageList.prototype, "params", {
                set: function (value) {
                    this._params = value;
                    if (!this._renderList || !this._renderList.length)
                        return;
                    this._renderList.forEach(function (render) {
                        if (render)
                            render.params = value;
                    });
                },
                enumerable: true,
                configurable: true
            });
            PageList.prototype.onTouchBegin = function (e) {
                this._isInTouch = true;
            };
            PageList.prototype.onTouchEnd = function (e) {
                this._isInTouch = false;
            };
            /**绑定滚动 */
            PageList.prototype.bindScroller = function (rect, scrollType) {
                if (scrollType === void 0) { scrollType = 0; }
                var scroller = new sui.Scroller();
                scroller.scrollType = scrollType;
                scroller.bindObj(this, rect);
            };
            /**
             * list 赋值
             *
             * @param {T[]} [data]
             * @param {*} [params] 额外参数
             * @returns
             *
             * @memberOf NewPageList
             */
            PageList.prototype.displayList = function (data, params) {
                // this.clear();
                this._data = data;
                this._params = params;
                if (!data || !data.length) {
                    this.dispose();
                    this.dataLen = 0;
                    return;
                }
                this.dataLen = data.length;
                for (var i = 0; i < this.dataLen; i++) {
                    this._waitUpdateIndexs.pushOnce(i);
                }
                this.sortChildren();
                if (this.scroller && !this._isInTouch) {
                    this.scroller.scrollToHead();
                }
                this.scrollPositionChange();
                if (this._selectedIndex == -1 || this._selectedIndex >= this.dataLen) {
                    this.selectedIndex = 0;
                }
            };
            PageList.prototype.scrollPositionChange = function (e) {
                var rect = this.scrollRect;
                if (!this._data)
                    return;
                var dlen = this.dataLen;
                var startIndex = undefined;
                var endIndex;
                //如果没有绑定滚动条的，那么就表示全在视野内，一次性全部加载渲染
                //如果绑定滚动条了，找到视野内最上（左）边的itemindex，作为起始点
                if (!rect) {
                    startIndex = 0;
                    endIndex = startIndex + dlen - 1;
                }
                else {
                    var r = this._renderRect;
                    for (var i = 0; i < dlen; i++) {
                        var _a = this.getRenderPosByIndex(i), x = _a[0], y = _a[1];
                        r.setTo(x, y, this._columnWidth, this._rowHeight);
                        if (startIndex == undefined) {
                            if (rect.intersects(r)) {
                                startIndex = i;
                            }
                        }
                        else {
                            if (!rect.intersects(r)) {
                                endIndex = i;
                                break;
                            }
                        }
                    }
                }
                if (endIndex == undefined)
                    endIndex = dlen - 1;
                endIndex = Math.min(endIndex, dlen - 1);
                this.startIndex = startIndex;
                this.endIndex = endIndex;
                this.doRenderListItem(startIndex, endIndex);
            };
            /**
           * 渲染指定位置的render
           *
           * @ protected
           * @ param {number} start (起始索引)
           * @ param {number} end (结束索引)
           */
            PageList.prototype.doRenderListItem = function (start, end) {
                var render;
                var len = this._renderList.length;
                for (var i = 0; i < len; i++) {
                    if (start <= i && i <= end)
                        continue;
                    render = this._renderList[i];
                    if (!render)
                        continue;
                    this.recycleRender(render);
                    this._renderList[i] = undefined;
                }
                var data = this._data;
                for (var i = start; i <= end; i++) {
                    render = this.getOrCreateItemRenderAt(i);
                    var tmp = render.getData();
                    if (!tmp || tmp != data[i] || render["dataChange"] || this._waitUpdateIndexs.indexOf(i) != -1) {
                        render.setData(data[i]);
                        render.handleView();
                        if (render["dataChange"]) {
                            render["dataChange"] = false;
                        }
                        this._waitUpdateIndexs.remove(i);
                    }
                    var _a = this.getRenderPosByIndex(i), x = _a[0], y = _a[1];
                    render.x = x;
                    render.y = y;
                    this.addChild(render);
                }
            };
            PageList.prototype.getOrCreateItemRenderAt = function (index) {
                var render = this._renderList[index];
                if (!render) {
                    render = shao.ObjectPool.getObject(this._renderClass);
                    render.on(-1001 /* ITEM_TOUCH_TAP */, this.touchItemrender, this);
                    if ("inited" in render) {
                        if (!render["inited"]) {
                            render["bindComponent"]();
                        }
                    }
                    this._renderList[index] = render;
                }
                if ("index" in render) {
                    render["index"] = index;
                    render.isFirst = index == 0;
                    render.isLast = index == this.dataLen - 1;
                }
                render.setChooseState(index == this.selectedIndex ? true : false);
                render.params = this._params;
                return render;
            };
            PageList.prototype.touchItemrender = function (e) {
                if (this._selectFunction && !this._selectFunction(e.target)) {
                    return;
                }
                this.selectedItem = e.target;
            };
            /**
             * 回收Render
             *
             * @protected
             *
             * @memberOf NewPageList
             */
            PageList.prototype.recycleRender = function (render) {
                if (render) {
                    shao.removeDisplay(render.renderView);
                    shao.ObjectPool.disposeObject(render);
                }
            };
            /**
             * 据index取得位置
             *
             * @protected
             * @param {number} index
             * @returns {[number, number]}
             *
             * @memberOf NewPageList
             */
            PageList.prototype.getRenderPosByIndex = function (index) {
                var x;
                var y;
                var count = this._columnCount;
                var m = Math.floor(index / count);
                var n = index % count;
                if (this._train) {
                    x = n * this._columnWidth;
                    y = m * this._rowHeight;
                }
                else {
                    x = m * this._columnWidth;
                    y = n * this._rowHeight;
                }
                return [x, y];
            };
            PageList.prototype.sortChildren = function () {
                var len = this.dataLen;
                var m = Math.ceil(len / this._columnCount);
                var n = len % this._columnCount;
                if (this._train) {
                    this.height = m * this._rowHeight;
                    if (m > 1 || n == 0)
                        n = this._columnCount;
                    this.width = n * this._columnWidth;
                }
                else {
                    this.width = m * this._columnWidth;
                    if (m > 1 || n == 0)
                        n = this._columnCount;
                    this.height = n * this._rowHeight;
                }
                var g = this.graphics;
                var rect = this.scrollRect;
                g.clear();
                if (rect) {
                    g.beginFill(0, 0);
                    g.drawRect(rect.x, rect.y, rect.width, rect.height);
                    g.endFill();
                }
            };
            PageList.prototype.moveScroll = function (value) {
                if (!this.scrollRect)
                    return;
                var rect = this.scrollRect;
                var _a = this.getRenderPosByIndex(value), rx = _a[0], ry = _a[1];
                var oldPos;
                var dis;
                if (!this.scroller)
                    return;
                if (this.scroller.scrollType == 1) {
                    oldPos = rect.x;
                    rect.x = rx + (this._columnWidth - rect.width) / 2;
                    if (rect.x <= 0) {
                        rect.x = 0;
                    }
                    this.scrollRect = rect;
                    dis = rect.x - oldPos;
                }
                else {
                    oldPos = rect.y;
                    rect.y = ry + (this._rowHeight - rect.height) / 2;
                    if (rect.y <= 0) {
                        rect.y = 0;
                    }
                    this.scrollRect = rect;
                    dis = rect.y - oldPos;
                }
                this.scrollPositionChange();
                // let scroller = this.scroller;
                // if (scroller) {
                // 	scroller.doMoveScrollBar(-dis);
                // }
            };
            PageList.prototype.getRenderList = function () {
                return this._renderList;
            };
            PageList.prototype.dispose = function () {
                this.recycle();
            };
            PageList.prototype.recycle = function () {
                this.clear();
                this.graphics.clear();
                this.width = 0;
                this.height = 0;
                this._data = undefined;
                this._selectedIndex = -1;
                this._waitUpdateIndexs = [];
                this.params = undefined;
            };
            PageList.prototype.clear = function () {
                var _this = this;
                this._renderList.forEach(function (render) {
                    if (render) {
                        _this.recycleRender(render);
                    }
                });
                this._renderList.length = 0;
            };
            PageList.prototype.moveTo = function (x, y) {
                this.x = x;
                this.y = y;
            };
            /**
           * 强制刷新指定render
           *
           * @param {string} key
           * @param {*} value
           * @param {*} data
           *
           * @memberOf NewPageList
           */
            PageList.prototype.updateItemDataByData = function (key, value, data) {
                var _a = this.getItemRenderAndIndex(key, value), item = _a[0], index = _a[1];
                if (item) {
                    item.setData(data);
                }
                else {
                    this._waitUpdateIndexs.pushOnce(index);
                }
                if (this._data && index in this._data) {
                    this._data[index] = data;
                }
            };
            /**
              * 强制刷新指定render
              *
              * @param {*} data
              *
              * @memberOf NewPageList
              */
            PageList.prototype.updateItemByData = function (data) {
                var index = this._data.indexOf(data);
                if (index == -1)
                    return;
                var render = this._renderList[index];
                if (render) {
                    render.setData(data);
                }
                else {
                    this._waitUpdateIndexs.pushOnce(index);
                }
                this._data[index] = data;
            };
            /**
             * 强制刷新指定render
             *
             * @param {string} key
             * @param {*} value
             *
             * @memberOf PageList
             */
            PageList.prototype.updateItemByKey = function (key, value) {
                var _a = this.getItemRenderAndIndex(key, value), item = _a[0], index = _a[1];
                if (item) {
                    item.refreshData();
                }
                else {
                    this._waitUpdateIndexs.pushOnce(index);
                }
            };
            /**
             * 整体更新
             *
             *
             * @memberOf NewPageList
             */
            PageList.prototype.updateAll = function () {
                for (var i = 0; i < this.dataLen; i++) {
                    var render = this._renderList[i];
                    if (render) {
                        render.refreshData();
                    }
                    else {
                        this._waitUpdateIndexs.pushOnce(i);
                    }
                }
            };
            /**
            *
            * 通过搜索数据，获取Render
            * @param {string} key
            * @param {*} value
            * @returns
            */
            PageList.prototype.getItemRenderAndIndex = function (key, value) {
                var data = this._data;
                if (!data)
                    return [null, -1];
                var len = data.length;
                var item;
                var i = 0;
                for (; i < len; i++) {
                    var dat = data[i];
                    if (dat) {
                        if (key in dat) {
                            if (dat[key] == value) {
                                item = this.getItemRenderAt(i);
                                break;
                            }
                        }
                    }
                }
                return [item, i];
            };
            /**
            *
            * 通过搜索数据，获取Render
            * @param {string} key
            * @param {*} value
            * @returns
            */
            PageList.prototype.getItemRender = function (key, value) {
                var data = this._data;
                if (!data)
                    return null;
                var len = data.length;
                var item;
                var i = 0;
                for (; i < len; i++) {
                    var dat = data[i];
                    if (dat) {
                        if (key in dat) {
                            if (dat[key] == value) {
                                return this.getItemRenderAt(i);
                            }
                        }
                    }
                }
                return null;
            };
            /**
            *
            * 通过搜索数据，获取Render
            * @param {string} key
            * @param {*} value
            * @returns
            */
            PageList.prototype.getItemRenderByData = function (value) {
                var data = this._data;
                if (!data)
                    return null;
                var i = data.indexOf(value);
                return this.getItemRenderAt(i);
            };
            /**
             *
             * 根据索引获得视图
             * @param {number} index
             * @returns
             */
            PageList.prototype.getItemRenderAt = function (index) {
                return this._renderList[index];
            };
            Object.defineProperty(PageList.prototype, "selectData", {
                get: function () {
                    if (!this._data)
                        return undefined;
                    return this._data[this._selectedIndex];
                },
                set: function (data) {
                    if (this._data)
                        this.selectedIndex = this._data.indexOf(data);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PageList.prototype, "selectedItem", {
                get: function () {
                    var render = this._renderList[this._selectedIndex];
                    return render;
                },
                set: function (value) {
                    var data = value.getData();
                    this.selectedIndex = this._data.indexOf(data);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PageList.prototype, "height", {
                get: function () {
                    return this._height;
                },
                set: function (value) {
                    if (this._height == value)
                        return;
                    this._height = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PageList.prototype, "width", {
                get: function () {
                    return this._width;
                },
                set: function (value) {
                    if (this._width == value)
                        return;
                    this._width = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PageList.prototype, "selectedIndex", {
                get: function () {
                    return this._selectedIndex;
                },
                set: function (value) {
                    //if (this._selectedIndex == value) return;
                    var render = this._renderList[this._selectedIndex];
                    if (render) {
                        render.setChooseState(false);
                    }
                    this._selectedIndex = value;
                    //滚动到选中处
                    if (this.isNeedMoveToSelect) {
                        this.moveScroll(this._selectedIndex);
                    }
                    render = this._renderList[this._selectedIndex];
                    if (render) {
                        render.setChooseState(true);
                    }
                    this.dispatchEventWith(PageList.ITEM_SELECTED);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PageList.prototype, "showWidth", {
                /**显示宽度 */
                get: function () {
                    if (!this.scrollRect) {
                        return this.width;
                    }
                    return Math.min(this.width, this.scrollRect.width);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PageList.prototype, "showHeight", {
                /**显示高度 */
                get: function () {
                    if (!this.scrollRect) {
                        return this.height;
                    }
                    return Math.min(this.height, this.scrollRect.height);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PageList.prototype, "dataLength", {
                get: function () {
                    return this.dataLen;
                },
                enumerable: true,
                configurable: true
            });
            PageList.prototype.getCurrentScrollRectPosition = function () {
                if (!this.scrollRect)
                    return 0;
                return this.scrollRect.x;
            };
            PageList.prototype.setScrollRectPosition = function (value) {
                if (!this.scrollRect)
                    return;
                if (this._isInTouch)
                    return;
                var rect = this.scrollRect;
                value = Math.min(this.width - rect.width, value);
                value = Math.max(value, 0);
                rect.x = value;
                this.scrollRect = rect;
                this.scrollPositionChange();
            };
            Object.defineProperty(PageList.prototype, "SelectFunction", {
                set: function (func) {
                    this._selectFunction = func;
                },
                enumerable: true,
                configurable: true
            });
            PageList.ITEM_SELECTED = "ITEM_SELECTED";
            return PageList;
        }(egret.Sprite));
        sui.PageList = PageList;
        __reflect(PageList.prototype, "shao.sui.PageList");
    })(sui = shao.sui || (shao.sui = {}));
})(shao || (shao = {}));
//# sourceMappingURL=PageList.js.map