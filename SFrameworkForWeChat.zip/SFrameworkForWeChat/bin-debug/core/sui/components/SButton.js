var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var sui;
    (function (sui) {
        var SButton = (function () {
            function SButton(btn) {
                // super();
                this._btn = btn;
                this.setTouchUtil(true);
            }
            Object.defineProperty(SButton.prototype, "enabled", {
                set: function (value) {
                    if (this.enabled != value) {
                        // this.filters = value ? null : FilterUtil.DarkGrayFilter;
                    }
                    this.setTouchUtil(value);
                },
                enumerable: true,
                configurable: true
            });
            SButton.prototype.setTouchUtil = function (value) {
                var util = this.touchUtil;
                if (util == undefined && value) {
                    util = this.touchUtil = new sui.TouchUtil(this._btn);
                }
                if (util) {
                    util.enabled = value;
                }
            };
            /**
             * 绑定TOUCH_TAP的回调
             *
             * @param {Function} handler
             * @param {*} thisObject
             * @param {number} [priority]
             * @param {boolean} [useCapture]
             *
             * @memberOf Button
             */
            SButton.prototype.bindTouch = function (handler, thisObject, priority, useCapture) {
                this._btn.on(egret.TouchEvent.TOUCH_TAP, handler, thisObject, useCapture, priority);
            };
            /**
             * 解除TOUCH_TAP的回调的绑定
             *
             * @param {Function} handler
             * @param {*} thisObject
             * @param {boolean} [useCapture]
             *
             * @memberOf Button
             */
            SButton.prototype.looseTouch = function (handler, thisObject, useCapture) {
                this._btn.off(egret.TouchEvent.TOUCH_TAP, handler, thisObject, useCapture);
            };
            return SButton;
        }());
        sui.SButton = SButton;
        __reflect(SButton.prototype, "shao.sui.SButton");
    })(sui = shao.sui || (shao.sui = {}));
})(shao || (shao = {}));
//# sourceMappingURL=SButton.js.map