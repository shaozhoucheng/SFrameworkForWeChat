var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var sui;
    (function (sui) {
        /**
         * 模块面板
         * @author builder
         *
         */
        var Panel = (function (_super) {
            __extends(Panel, _super);
            function Panel() {
                var _this = _super.call(this) || this;
                _this.loadSkin = false;
                _this.loadThm = false;
                _this._scaled = false;
                _this._showing = false;
                _this.init();
                _this.touchEnabled = true;
                _this.on(egret.Event.ADDED_TO_STAGE, _this.addedToStage, _this);
                return _this;
            }
            /**
             * 面板在fla中的原始坐标
             *
             * @protected
             * @type {egret.Rectangle}
             */
            // protected _baseRect: egret.Rectangle;
            /**修改界面大小 */
            Panel.prototype.resizeBaseRect = function (w, h) {
                // this._baseRect.width = w;
                // this._baseRect.height = h;
            };
            Object.defineProperty(Panel.prototype, "isReady", {
                get: function () {
                    return this._ready;
                },
                enumerable: true,
                configurable: true
            });
            Panel.prototype.addReadyExecute = function (handle, thisObj) {
                var args = [];
                for (var _i = 2; _i < arguments.length; _i++) {
                    args[_i - 2] = arguments[_i];
                }
                var _asyncHelper = this._asyncHelper;
                if (!_asyncHelper) {
                    this._asyncHelper = _asyncHelper = new shao.mvc.AsyncHelper();
                    _asyncHelper._ready = this.isReady;
                }
                _asyncHelper.addReadyExecute(handle, thisObj, args);
            };
            Panel.prototype.init = function () {
            };
            Panel.prototype.startSync = function () {
                //目前没搞清egret component 加载这块 直接ready
                if (!this._thmName) {
                    this.loadThm = true;
                    this.thmDataComplete();
                }
                if (!this.loadThm) {
                    this.loadThm = true;
                    var theme = new eui.Theme(this._thmName, this.stage);
                    theme.addEventListener(eui.UIEvent.COMPLETE, this.thmDataComplete, this);
                }
                // this.skinDataComplete();
            };
            Panel.prototype.thmDataComplete = function (e) {
                if (!this._key) {
                    this.loadSkin = true;
                    this.skinDataComplete();
                }
                if (!this.loadSkin) {
                    this.loadSkin = true;
                    RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.skinDataComplete, this);
                    RES.loadGroup(this._key); //加载资源组对应的图片
                }
            };
            Panel.prototype.skinDataComplete = function (e) {
                RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.skinDataComplete, this);
                this.exmlDataComplete();
                // EXML.load(this.skinName, this.exmlDataComplete, this)
            };
            Panel.prototype.doScale = function (scale) {
                if (!this._scaled) {
                    this.scaleX = this.scaleY = scale;
                    this._scaled = true;
                }
                var offSet = 1 - scale;
                var offH = Math.round(offSet * this.width);
                var offV = Math.round(offSet * this.height);
                return { offH: offH, offV: offV };
            };
            Panel.prototype.loadNext = function () {
                // if (this._depends.length) {
                //     var key = this._depends.pop();
                //     // var suiManager = SuiResManager.getInstance();
                //     // suiManager.loadData(key, this);
                // }
                // else {
                //     this.skinDataComplete();
                // }
            };
            // protected createChildren()
            // {
            //     super.createChildren();
            //     this.skinDataComplete();
            // }
            /**
             * 皮肤数据加载完成
             */
            Panel.prototype.exmlDataComplete = function () {
                this.bindComponents();
                if (this["bg"]) {
                    this["bg"].touchEnabled = true;
                }
                if (this["closeBtn"]) {
                    this.closable = true;
                }
                if (this["helpBtn"]) {
                    this.helpable = true;
                }
                if (this["returnBtn"]) {
                    this.returnable = true;
                }
                this._ready = true;
                if (this._asyncHelper) {
                    this._asyncHelper.readyNow();
                }
            };
            Object.defineProperty(Panel.prototype, "helpable", {
                get: function () {
                    return this._helpable;
                },
                set: function (value) {
                    this._helpable = value;
                    if (value && this["helpBtn"]) {
                        this["helpBtn"].addEventListener(egret.TouchEvent.TOUCH_TAP, this.showHelp, this);
                    }
                    else if (this["helpBtn"]) {
                        this["helpBtn"].removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showHelp, this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Panel.prototype, "returnable", {
                get: function () {
                    return this._helpable;
                },
                set: function (value) {
                    this._helpable = value;
                    if (value && this["returnBtn"]) {
                        this["returnBtn"].addEventListener(egret.TouchEvent.TOUCH_TAP, this.return, this);
                    }
                    else if (this["returnBtn"]) {
                        this["returnBtn"].removeEventListener(egret.TouchEvent.TOUCH_TAP, this.return, this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Panel.prototype, "closable", {
                get: function () {
                    return this._closable;
                },
                set: function (value) {
                    this._closable = value;
                    if (value && this["closeBtn"]) {
                        this["closeBtn"].addEventListener(egret.TouchEvent.TOUCH_TAP, this.hide, this);
                    }
                    else if (this["closeBtn"]) {
                        this["closeBtn"].removeEventListener(egret.TouchEvent.TOUCH_TAP, this.hide, this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Panel.prototype, "isModal", {
                get: function () {
                    return this._isModal;
                },
                set: function (value) {
                    this._isModal = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Panel.prototype, "width", {
                get: function () {
                    // if(this.modal){
                    //     return Panel.WIDTH;
                    // }
                    return this.skin.width;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Panel.prototype, "height", {
                get: function () {
                    // if(this.modal){
                    //     return Panel.HEIGHT;
                    // }
                    return this.skin.height;
                },
                enumerable: true,
                configurable: true
            });
            /**
             * 加模态
             *
             * @protected
             */
            Panel.prototype.addModal = function (flag, active) {
                if (flag === void 0) { flag = true; }
                if (active === void 0) { active = true; }
                if (!this.modal) {
                    this.modal = new egret.Shape();
                }
                var m = this.modal;
                m.touchEnabled = true;
                var stage = egret.sys.$TempStage;
                var g = m.graphics;
                g.clear();
                g.beginFill(Panel.MODAL_COLOR, Panel.MODAL_ALPHA);
                g.drawRect(0, 0, stage.stageWidth, stage.stageHeight);
                g.endFill();
                if (active) {
                    this.modal.on(egret.TouchEvent.TOUCH_TAP, this.hide, this);
                }
                var index = this.parent.getChildIndex(this);
                this.parent.addChildAt(this.modal, index);
            };
            /**
             * 移除模态
             *
             * @protected
             */
            Panel.prototype.removeModal = function () {
                if (this.modal) {
                    this.modal.off(egret.TouchEvent.TOUCH_TAP, this.hide, this);
                    shao.removeDisplay(this.modal);
                }
            };
            Panel.prototype.showHelp = function (event) {
                var f = shao.$facade;
                var mm = f.moduleManager;
                var cfg = mm.getCfg(this.moduleID);
                if (cfg.help) {
                    shao.$facade.executeMediator("Help", false, "setData", true, undefined, cfg.help);
                }
            };
            Panel.prototype.return = function (e) {
                if (this.preModuleID) {
                    shao.$facade.toggle(this.preModuleID, 1);
                }
                if (event) {
                    event.stopPropagation();
                }
                shao.$facade.toggle(this.moduleID, 0);
            };
            Panel.prototype.show = function (container) {
                var f = shao.$facade;
                var mm = f.moduleManager;
                var cfg = mm.getCfg(this.moduleID);
                if (!cfg.help && this["helpBtn"]) {
                    this["helpBtn"].visible = false;
                }
                cfg.showState = shao.mvc.ModuleShowState.SHOW;
                if (!container) {
                    container = shao.game.GameEngine.instance.getLayer(cfg.containerID);
                }
                this.includeState.awaken();
                if (!this.includeState.checkCanShow(container, true))
                    return;
                container.addChild(this);
                if (cfg.scale) {
                    var off = this.doScale(cfg.scale);
                    if (!this._showing) {
                        this.doOffSet(off);
                    }
                }
                shao.PanelLimit.add(this.moduleID);
                shao.mvc.Facade.simpleDispatch(0 /* SIDE_MODULE_SHOW */, cfg);
                this._showing = true;
            };
            Panel.prototype.stageResize = function () {
                var f = shao.$facade;
                var mm = f.moduleManager;
                var cfg = mm.getCfg(this.moduleID);
                this._scaled = false;
                if (cfg.scale) {
                    var off = this.doScale(cfg.scale);
                    this.doOffSet(off);
                }
            };
            Panel.prototype.doOffSet = function (off) {
                var layout = this.layoutType;
                //垂直方向
                var vertical = layout & 12 /* VERTICAL_MASK */;
                //水平方向
                var horizon = layout & 3 /* HORIZON_MASK */;
                //先处理y方向
                switch (vertical) {
                    case 4 /* TOP */:
                        break;
                    case 8 /* MIDDLE */:
                        this.y += off.offV / 2;
                        break;
                    case 12 /* BOTTOM */:
                        this.y += off.offV;
                        break;
                }
                //再处理x方向
                switch (horizon) {
                    case 1 /* LEFT */:
                        break;
                    case 2 /* CENTER */:// 不支持非innerH
                        this.x += off.offH / 2;
                        break;
                    case 3 /* RIGHT */:
                        this.x += off.offH;
                        break;
                }
            };
            /**
              * 关闭
              *
              * @protected
              */
            Panel.prototype.hide = function (event) {
                // super.hide();
                var f = shao.$facade;
                var mm = f.moduleManager;
                var cfg = mm.getCfg(this.moduleID);
                cfg.showState = shao.mvc.ModuleShowState.HIDE;
                this.includeState.sleep();
                shao.removeDisplay(this);
                shao.PanelLimit.remove(this.moduleID);
                shao.mvc.Facade.simpleDispatch(1 /* SIDE_MODULE_HIDE */, cfg);
                this._showing = false;
            };
            Panel.prototype.changeShow = function (flag) {
                if (!flag) {
                    this._showing = false;
                }
                else {
                    this.show();
                }
            };
            Panel.prototype.addedToStage = function (e) {
                if (this._isModal) {
                    this.addModal(true);
                }
                this.off(egret.Event.ADDED_TO_STAGE, this.addedToStage, this);
                this.on(egret.Event.REMOVED_FROM_STAGE, this.removedToStage, this);
            };
            Panel.prototype.removedToStage = function (e) {
                this.removeModal();
                this.on(egret.Event.ADDED_TO_STAGE, this.addedToStage, this);
                this.off(egret.Event.REMOVED_FROM_STAGE, this.removedToStage, this);
                if (this._isModal) {
                    this.modal.off(egret.TouchEvent.TOUCH_TAP, this.hide, this);
                }
                this._showing = false;
            };
            /**
             * 模态颜色
             *
             * @static
             * @type {number}
             */
            Panel.MODAL_COLOR = 0x000000;
            /**
             * 模态透明度
             *
             * @static
             * @type {number}
             */
            Panel.MODAL_ALPHA = 0.2;
            return Panel;
        }(shao.TStatePanel));
        sui.Panel = Panel;
        __reflect(Panel.prototype, "shao.sui.Panel", ["shao.mvc.IAsyncPanel", "egret.DisplayObject", "shao.mvc.IAsync", "shao.mvc.IModulePanel"]);
    })(sui = shao.sui || (shao.sui = {}));
})(shao || (shao = {}));
//# sourceMappingURL=Panel.js.map