var shao;
(function (shao) {
    var sui;
    (function (sui) {
        /**
         *
         * @author builder
         *
         */
        sui.Layout = {
            /**
             * 对DisplayObject，基于父级进行排布
             *
             * @static
             * @ param {egret.DisplayObject} dis 要布局的可视对象
             * @ param {number} layout 布局方式
             * @ param {number} hoffset 在原布局基础上，水平方向的再偏移量（内部运算是"+",向左传负）
             * @ param {number} voffset 在原布局基础上，垂直方向的再偏移量（内部运算是"+",向上传负）
             * @ param {boolean} [innerV=true] 垂直方向上基于父级内部
             * @ param {boolean} [innerH=true] 水平方向上基于父级内部
             * @ param {egret.DisplayObjectContainer} [parent] 父级容器，默认取可视对象的父级
             */
            layout: function (dis, layout, hoffset, voffset, innerV, innerH, parent) {
                if (hoffset === void 0) { hoffset = 0; }
                if (voffset === void 0) { voffset = 0; }
                if (innerV === void 0) { innerV = true; }
                if (innerH === void 0) { innerH = true; }
                var parentWidth = 0;
                var parentHeight = 0;
                var posx = 0;
                var posy = 0;
                if (!parent) {
                    parent = dis.parent;
                }
                if (parent) {
                    if (shao.is(parent, egret.Stage)) {
                        parentWidth = parent.stageWidth;
                        parentHeight = parent.stageHeight;
                    }
                    else if (parent instanceof shao.game.GameLayer) {
                        var stage = egret.sys.$TempStage;
                        parentWidth = stage.stageWidth;
                        parentHeight = stage.stageHeight;
                    }
                    else {
                        parentWidth = parent.width;
                        parentHeight = parent.height;
                    }
                }
                var vertical = layout & 12 /* VERTICAL_MASK */;
                var horizon = layout & 3 /* HORIZON_MASK */;
                switch (vertical) {
                    case 4 /* TOP */:
                        if (innerV) {
                            posy = 0;
                        }
                        else {
                            posy = -dis.height;
                        }
                        break;
                    case 8 /* MIDDLE */:// 不支持非innerV
                        posy = parentHeight - dis.height >> 1;
                        break;
                    case 12 /* BOTTOM */:
                        if (innerV) {
                            posy = parentHeight - dis.height;
                        }
                        else {
                            posy = parentHeight;
                        }
                        break;
                }
                switch (horizon) {
                    case 1 /* LEFT */:
                        if (innerH) {
                            posx = 0;
                        }
                        else {
                            posx = -dis.width;
                        }
                        break;
                    case 2 /* CENTER */:// 不支持非innerH
                        posx = parentWidth - dis.width >> 1;
                        break;
                    case 3 /* RIGHT */:
                        if (innerH) {
                            posx = parentWidth - dis.width;
                        }
                        else {
                            posx = parentWidth;
                        }
                        break;
                }
                posx = posx + hoffset;
                posy = posy + voffset;
                dis.x = Math.round(posx);
                dis.y = Math.round(posy);
            }
        };
    })(sui = shao.sui || (shao.sui = {}));
})(shao || (shao = {}));
//# sourceMappingURL=Layout.js.map