var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var BaseScene = (function () {
        /**
         * 构造函数
         */
        function BaseScene() {
        }
        /**
         * 进入Scene调用
         */
        BaseScene.prototype.onEnter = function () {
        };
        /**
         * 退出Scene调用
         */
        BaseScene.prototype.onExit = function () {
        };
        return BaseScene;
    }());
    shao.BaseScene = BaseScene;
    __reflect(BaseScene.prototype, "shao.BaseScene");
})(shao || (shao = {}));
//# sourceMappingURL=BaseScene.js.map