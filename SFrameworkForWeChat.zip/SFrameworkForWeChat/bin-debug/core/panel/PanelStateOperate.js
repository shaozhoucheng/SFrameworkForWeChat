var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var PanelStateOperate = (function () {
        function PanelStateOperate() {
            this._stateDic = {};
        }
        /**
         * 更改状态
         * @param state
         * @param type 0:地图类型, 1:系统类型 (pk模式, 上帝模式, 引导模式)
         */
        PanelStateOperate.prototype.changeState = function (state, type) {
            if (type === void 0) { type = 0; }
            if (Number(this._stateDic[type]) == state)
                return;
            this._stateDic[type] = state;
            shao.TStatePanel.includehelp.dispatchEvent(new egret.Event(egret.Event.CHANGE));
        };
        PanelStateOperate.prototype.getState = function (type) {
            return this._stateDic[type];
        };
        PanelStateOperate.prototype.clearState = function (type) {
            if (this._stateDic[type] != null) {
                delete this._stateDic[type];
                shao.TStatePanel.includehelp.dispatchEvent(new egret.Event(egret.Event.CHANGE));
            }
        };
        Object.defineProperty(PanelStateOperate.prototype, "stateDic", {
            get: function () {
                return this._stateDic;
            },
            enumerable: true,
            configurable: true
        });
        PanelStateOperate.ins = new PanelStateOperate();
        return PanelStateOperate;
    }());
    shao.PanelStateOperate = PanelStateOperate;
    __reflect(PanelStateOperate.prototype, "shao.PanelStateOperate");
})(shao || (shao = {}));
//# sourceMappingURL=PanelStateOperate.js.map