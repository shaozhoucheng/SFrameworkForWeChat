var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var PanelLimit = (function () {
        function PanelLimit() {
        }
        PanelLimit.add = function (moduleid) {
            // let f = $facade;
            // let dic = DataLocator.getData(game.ConfigKey.JieMianHuChi);
            // let cfg: chuanqi.JieMianHuChiCfg = dic[moduleid] as chuanqi.JieMianHuChiCfg;
            // if (cfg) {
            // 	let len = this._showList.length;
            // 	for (let i: number = len - 1; i >= 0; i--) {
            // 		let id = this._showList[i];
            // 		if (cfg.isExclusion(id)) {
            // 			f.toggle(id, 0);
            // 			this.remove(id);
            // 		}
            // 	}
            // }
            // this._showList.push(moduleid);
        };
        PanelLimit.remove = function (moduleid) {
            this._showList.remove(moduleid);
        };
        /**
         * 关闭所有打开的面板
         *
         * @static
         *
         * @memberOf PanelLimit
         */
        PanelLimit.closeAll = function () {
            var len = this._showList.length;
            var facade = shao.$facade;
            for (var i = len - 1; i >= 0; i--) {
                var id = this._showList[i];
                var cfg = facade.moduleManager.getCfg(id);
                if (cfg.containerID == 8700) {
                    facade.toggle(id, 0);
                    this.remove(id);
                }
            }
        };
        PanelLimit._showList = [];
        return PanelLimit;
    }());
    shao.PanelLimit = PanelLimit;
    __reflect(PanelLimit.prototype, "shao.PanelLimit");
})(shao || (shao = {}));
//# sourceMappingURL=PanelLimit.js.map