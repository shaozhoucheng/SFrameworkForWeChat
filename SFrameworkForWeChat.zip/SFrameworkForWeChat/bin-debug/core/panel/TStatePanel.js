var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var TStatePanel = (function (_super) {
        __extends(TStatePanel, _super);
        function TStatePanel() {
            return _super.call(this) || this;
        }
        /**
         * 修改state
         * @param state
         *
         */
        TStatePanel.changeState = function (state) {
            shao.PanelStateOperate.ins.changeState(state, 0 /* TYPE_MAP */);
        };
        Object.defineProperty(TStatePanel.prototype, "includeState", {
            get: function () {
                if (!this._includeState) {
                    this._includeState = new shao.PanelState(this);
                }
                return this._includeState;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 除了那些都显示
         */
        TStatePanel.prototype.includeOut = function () {
            var arg = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                arg[_i] = arguments[_i];
            }
            this.includeState.includeOut(arg);
        };
        /**
         * 只显示在固定的地方
         */
        TStatePanel.prototype.includeIn = function () {
            var arg = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                arg[_i] = arguments[_i];
            }
            this.includeState.includeIn(arg);
        };
        TStatePanel.prototype.toggleState = function (toShow) {
            if (toShow) {
                if (this.includeState.includeParent) {
                    this.includeState.includeParent.addChildAt(this, 0);
                    this.changeShow(true);
                }
            }
            else {
                if (this.parent) {
                    this.parent.removeChild(this);
                    this.changeShow(false);
                }
            }
        };
        TStatePanel.prototype.changeShow = function (flag) {
        };
        TStatePanel.includehelp = new egret.EventDispatcher();
        return TStatePanel;
    }(eui.Component));
    shao.TStatePanel = TStatePanel;
    __reflect(TStatePanel.prototype, "shao.TStatePanel");
})(shao || (shao = {}));
//# sourceMappingURL=TStatePanel.js.map