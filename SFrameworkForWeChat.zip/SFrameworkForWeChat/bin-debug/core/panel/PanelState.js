var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var PanelState = (function () {
        function PanelState(panel) {
            this._panel = panel;
        }
        PanelState.prototype.includeIn = function (states) {
            this.includeFlag = true;
            this.includes = states;
        };
        PanelState.prototype.includeOut = function (states) {
            this.includeFlag = false;
            this.includes = states;
        };
        PanelState.prototype.refresh = function (e) {
            if (!this.includes)
                return;
            var _panel = this._panel;
            var curP = _panel ? _panel.parent : null;
            _panel.toggleState(this.checkCanShow(curP, this.includeFlag));
        };
        PanelState.prototype.checkCanShow = function (parent, flag) {
            if (flag === void 0) { flag = false; }
            if (!this.includes) {
                return true;
            }
            if (parent && (!this._includeParent || flag)) {
                this._includeParent = parent;
            }
            var stateDic = shao.PanelStateOperate.ins.stateDic;
            for (var i in stateDic) {
                var itemState = stateDic[i];
                if (this.includeFlag && this.includes.indexOf(itemState) == -1) {
                    return false;
                }
                if (!this.includeFlag && this.includes.indexOf(itemState) != -1) {
                    return false;
                }
            }
            return true;
        };
        Object.defineProperty(PanelState.prototype, "includeParent", {
            get: function () {
                return this._includeParent;
            },
            enumerable: true,
            configurable: true
        });
        PanelState.prototype.awaken = function () {
            if (!this.includes)
                return;
            shao.TStatePanel.includehelp.on(egret.Event.CHANGE, this.refresh, this);
        };
        PanelState.prototype.sleep = function () {
            if (!this.includes)
                return;
            this._includeParent = null;
            shao.TStatePanel.includehelp.off(egret.Event.CHANGE, this.refresh, this);
        };
        return PanelState;
    }());
    shao.PanelState = PanelState;
    __reflect(PanelState.prototype, "shao.PanelState");
})(shao || (shao = {}));
//# sourceMappingURL=PanelState.js.map