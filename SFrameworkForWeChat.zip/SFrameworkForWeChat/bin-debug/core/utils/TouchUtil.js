var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var sui;
    (function (sui) {
        var TouchUtil = (function () {
            function TouchUtil(target) {
                this._enabled = false;
                this.isTouchBegin = false;
                this.target = target;
                this.recordStartXY();
                if ("touchChildren" in target) {
                    target["touchChildren"] = false;
                }
            }
            TouchUtil.prototype.dispose = function () {
                var t = this.target;
                if (t) {
                    var type = egret.Event.ADDED_TO_STAGE;
                    if (t.hasEventListener(type)) {
                        t.removeEventListener(type, this.targetAddedToParent, this);
                    }
                    t = undefined;
                    this.enabled = false;
                    this.target = null;
                }
            };
            Object.defineProperty(TouchUtil.prototype, "enabled", {
                set: function (value) {
                    if (value != this._enabled) {
                        var t = this.target;
                        if (t) {
                            var type = egret.TouchEvent.TOUCH_BEGIN;
                            t.touchEnabled = value;
                            if (value)
                                t.addEventListener(type, this.touchBegin, this);
                            else
                                t.removeEventListener(type, this.touchBegin, this);
                        }
                        this._enabled = value;
                    }
                },
                enumerable: true,
                configurable: true
            });
            TouchUtil.prototype.recordStartXY = function () {
                var t = this.target;
                if (t) {
                    var p = t.stage;
                    if (p)
                        this.enabled = t.touchEnabled;
                    else
                        t.addEventListener(egret.Event.ADDED_TO_STAGE, this.targetAddedToParent, this);
                }
            };
            TouchUtil.prototype.targetAddedToParent = function (event) {
                var t = event.currentTarget;
                t.removeEventListener(egret.Event.ADDED_TO_STAGE, this.targetAddedToParent, this);
                this.recordStartXY();
            };
            TouchUtil.prototype.touchBegin = function (event) {
                if (this.isTouchBegin)
                    this.touchEnd(null);
                this.isTouchBegin = true;
                var st = egret.sys.$TempStage;
                st.addEventListener(egret.TouchEvent.TOUCH_END, this.touchEnd, this);
                st.addEventListener(egret.TouchEvent.LEAVE_STAGE, this.touchLeaveStage, this);
                var t = this.target;
                t.scaleX = 1;
                t.scaleY = 1;
                var sc = 1.1;
                var sx = this.startx = t.x;
                var sy = this.starty = t.y;
                var sw = t.width;
                var sh = t.height;
                t.scaleX = sc;
                t.scaleY = sc;
                t.x = sx - sw * 0.05;
                t.y = sy - sh * 0.05;
            };
            TouchUtil.prototype.touchEnd = function (event) {
                var t = this.target;
                var st = egret.sys.$TempStage;
                st.removeEventListener(egret.TouchEvent.TOUCH_END, this.touchEnd, this);
                st.removeEventListener(egret.TouchEvent.LEAVE_STAGE, this.touchLeaveStage, this);
                t.scaleX = 1;
                t.scaleY = 1;
                t.x = this.startx;
                t.y = this.starty;
                this.isTouchBegin = false;
            };
            TouchUtil.prototype.touchLeaveStage = function (event) {
                this.touchEnd(event);
            };
            return TouchUtil;
        }());
        sui.TouchUtil = TouchUtil;
        __reflect(TouchUtil.prototype, "shao.sui.TouchUtil");
    })(sui = shao.sui || (shao.sui = {}));
})(shao || (shao = {}));
//# sourceMappingURL=TouchUtil.js.map