var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    /**
     * 数据缓存池
     * @author dai changxin
     */
    var ObjectPool = (function () {
        function ObjectPool() {
        }
        ObjectPool.getObject = function (type) {
            var pool = this.getPool(type);
            return pool.getInstance();
        };
        ObjectPool.disposeObject = function (object, type) {
            if (type === void 0) { type = null; }
            if (object == null)
                return;
            if (!type) {
                type = egret.getDefinitionByName(egret.getQualifiedClassName(object));
            }
            var r = this.getPool(type);
            r.recycle(object);
        };
        ObjectPool.getPool = function (type) {
            if (!this._poolDic) {
                this._poolDic = new shao.MapDict();
            }
            if (!this._poolDic.has(type)) {
                this._poolDic.set(type, new shao.RecyclablePool(type));
            }
            return this._poolDic.get(type);
        };
        return ObjectPool;
    }());
    shao.ObjectPool = ObjectPool;
    __reflect(ObjectPool.prototype, "shao.ObjectPool");
})(shao || (shao = {}));
//# sourceMappingURL=ObjectPool.js.map