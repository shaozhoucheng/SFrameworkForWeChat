var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        /**
         * description
         * @author pb
         */
        var Core = (function () {
            function Core() {
            }
            Object.defineProperty(Core, "inPVP", {
                get: function () {
                    return Core._inPVP;
                },
                // private static pvpRender: game.AniRender;
                set: function (value) {
                    // let ani = AniController.getInstance();
                    // Core._inPVP = value;
                    // if (Core.pvpRender) {
                    //     Core.pvpRender.recycle();
                    //     Core.pvpRender = undefined;
                    // }
                    // if (value) {
                    //     var engine = game.GameEngine.instance;
                    //     let stage = egret.sys.$TempStage;
                    //     let x = (stage.stageWidth - 380) >> 1;
                    //     let y = 480;
                    //     Core.pvpRender = ani.playAniByPosition(AniDefine.PVP_STATE, x, y, game.GameLayerID.UI);
                    // }
                },
                enumerable: true,
                configurable: true
            });
            Core.start = function () {
                // if (DEBUG) {
                //     let mouseCatcher = game.GameEngine.instance.getLayer(game.GameLayerID.Background);
                //     mouseCatcher.$touchEnabled = true;
                //     mouseCatcher.on(Event.TOUCH_TAP,
                //     function (event: Event): void {
                //         let now = Global.now;
                //         var engine = game.GameEngine.instance;
                //         var rect = engine.viewRect;
                //         var x = event.stageX + rect.x;
                //         var y = event.stageY + rect.y;
                //         let main = this.unitEntity;
                //         if (main) {
                //             main.changeState(UnitEntityState.waiting);
                //             main.setTarget();
                //             let pt = { x, y };
                //             screen2Map(pt);
                //             main.walkToPos(pt, now);
                //             main.setAIDelay(500);
                //         }
                //     }, this);
                //     // Global.callLater(this.sendLog, 10000, this);
                // }
            };
            Core.sendLog = function () {
                // let command = Command.getInstance();
                // command.readySendLog(24002, 43000);
                // console.log(`now addBody = ${lingyu.NameUtils.addBody}`)
                // console.log(`now addUI = ${lingyu.NameUtils.addUI}`)
                // console.log(`now removeBody = ${lingyu.NameUtils.removeBody}`)
                // console.log(`now removeUI = ${lingyu.NameUtils.removeUI}`)
                shao.Global.callLater(this.sendLog, 10000, this);
            };
            /**
             * 切换自动拾取
             *
             * @static
             *
             * @memberOf Core
             */
            Core.changePickState = function () {
                Core.autoPick = !Core.autoPick;
            };
            /**
             * 切换自动挑战BOSS
             *
             * @static
             *
             * @memberOf Core
             */
            // public static changeBossState(flag: boolean) {
            //     if (this._autoBoss == flag) return;
            //     this._autoBoss = flag;
            //     $saveSet(SetType.AutoBoss, flag ? "1" : "0");
            //     $facade.dispatchEventWith(EventConst.AUTOBOSS_STATE_CHANGE);
            //     if (flag) {
            //         if (!Core.$taskChapter) return;
            //         if (!Core.$taskChapter.state) return;
            //         $facade.getProxy(ServiceName.TaskService, (taskService: TaskService) => {
            //             let task = Core.$taskChapter.currentTask;
            //             if (task)
            //                 taskService.changeMap(task.mapid);
            //         });
            //     }
            // }
            Core.getAutoBoss = function () {
                return this._autoBoss;
            };
            /**
             * 切换自动挂机
             *
             * @static
             *
             * @memberOf Core
             */
            Core.changeAutoState = function (flag) {
                // if (flag) {
                //     Core.other = undefined;
                //     return;
                // }
                if (Core.other && Core.other.length) {
                    Core.other = undefined;
                }
                else {
                    Core.other = "1";
                }
            };
            /**
             * 晃动屏幕
             * @param type 1:圆形, 2:方向, 3:垂直, 4:旋转, 5:更大强度的圆形
             */
            Core.shakeStage = function (type, faceTo) {
                if (type === void 0) { type = 1; }
                if (faceTo === void 0) { faceTo = 0; }
                // getSinglon(ShakeManage).shakeStage(type, faceTo);
            };
            /**
             *
             * 主角新人信息（只有在新创建的时候才用到）
             *
             * @memberOf Core
             */
            Core.$newRole = false;
            /**
             * 技能测试（暂未使用）
             *
             * @static
             * @type {boolean}
             * @memberOf Core
             */
            Core.skillHelp = false;
            /**
             * 自动拾取
             *
             * @static
             * @type {boolean}
             * @memberOf Core
             */
            Core.autoPick = true;
            /**
             * 自动挑战BOSS
             *
             * @static
             * @type {boolean}
             * @memberOf Core
             */
            Core._autoBoss = false;
            /**
             * 相位状态
             *
             * @static
             * @type {boolean}
             * @memberOf Core
             */
            Core.inPhase = false;
            /**
             * 征战状态
             *
             * @static
             * @type {boolean}
             * @memberOf Core
             */
            Core._inPVP = false;
            /**
             * 打怪模式
             *
             * @static
             * @type {number}
             * @memberOf Core
             */
            Core.autoModes = 0;
            Core.login = false;
            Core.showAvatar = true;
            Core.showWing = true;
            Core.serverDate = new Date();
            Core.getServerDate = function () {
                Core.serverDate.setTime(shao.DateUtils.serverTime);
                return Core.serverDate;
            };
            /**倒计时10秒 */
            Core.COUNT_DOWN_10 = 10000;
            /**倒计时5秒 */
            Core.COUNT_DOWN_5 = 5000;
            return Core;
        }());
        game.Core = Core;
        __reflect(Core.prototype, "shao.game.Core");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=Core.js.map