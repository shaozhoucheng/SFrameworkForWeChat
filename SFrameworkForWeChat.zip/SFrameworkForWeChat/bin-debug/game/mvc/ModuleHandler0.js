var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        /**
         *
         * @author builder
         *
         */
        var ModuleHandler0 = (function (_super) {
            __extends(ModuleHandler0, _super);
            function ModuleHandler0() {
                return _super.call(this) || this;
            }
            /**
             * 打开某个模块
             * @param cfg
             */
            ModuleHandler0.prototype.open = function (cfg) {
                var args = [];
                for (var _i = 1; _i < arguments.length; _i++) {
                    args[_i - 1] = arguments[_i];
                }
                //找到指定模块，并打开面板
                shao.$facade.getMediator(cfg.id, this._showMediator, this, cfg, args);
            };
            ModuleHandler0.prototype._showMediator = function (mediator, args) {
                var cfg = args[0];
                var params = args[1];
                var preModuleID = params[0];
                var view = mediator.view;
                if (preModuleID) {
                    view.preModuleID = preModuleID;
                }
                var layer = game.GameEngine.instance.getLayer(cfg.containerID);
                if (layer) {
                    view.show(layer);
                }
                else {
                    console.log("mediator " + mediator.name + "without the layer");
                }
            };
            ModuleHandler0.prototype.close = function (cfg) {
                //找到指定模块，并打开面板
                shao.$facade.getMediator(cfg.id, this._hideMediator, this, cfg);
            };
            ModuleHandler0.prototype._hideMediator = function (mediator, args) {
                var view = mediator.view;
                view.hide();
            };
            return ModuleHandler0;
        }(shao.mvc.ModuleHandler));
        game.ModuleHandler0 = ModuleHandler0;
        __reflect(ModuleHandler0.prototype, "shao.game.ModuleHandler0");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=ModuleHandler0.js.map