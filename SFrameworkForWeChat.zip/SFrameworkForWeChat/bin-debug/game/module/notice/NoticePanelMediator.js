var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var NoticePanelMediator = (function (_super) {
            __extends(NoticePanelMediator, _super);
            function NoticePanelMediator() {
                return _super.call(this, game.ModuleId.Notice) || this;
            }
            NoticePanelMediator.prototype.init = function () {
                this.view = new game.NoticePanel;
                game.ResizeManager.getInstance().add(this.view, 10 /* MIDDLE_CENTER */);
                //这里加事件关注
            };
            NoticePanelMediator.prototype.afterAllReady = function () {
                var view = this.$view;
                view.bg.source = "resource/remote/i/start.jpg";
                // RES.getResByUrl("resource/remote/i/start.jpg", null, null, RES.ResourceItem.TYPE_IMAGE);
            };
            NoticePanelMediator.prototype.showAniBtn = function () {
                var view = this.$view;
                var ani = this.ani;
                if (ani) {
                    ani.onRecycle();
                    ani = undefined;
                }
                ani = this.ani = game.AniRender.getAni("NoticeStartBtn");
                ani.frameRate = 12;
                ani.play();
                var display = ani.displaymc;
                display.x = 235;
                display.y = 350;
                view.addChild(display);
                display.touchEnabled = true;
                display.on(egret.TouchEvent.TOUCH_TAP, this.onStartBtnTouch, this);
            };
            NoticePanelMediator.prototype.onStartBtnTouch = function (evt) {
                var newPlayer = true;
                if (newPlayer) {
                    shao.getInstance(shao.SceneManager).runScene(game.SceneConst.Story);
                }
                else {
                    shao.getInstance(shao.SceneManager).runScene(game.SceneConst.Home);
                }
            };
            NoticePanelMediator.prototype.awake = function () {
                this.showAniBtn();
            };
            NoticePanelMediator.prototype.sleep = function () {
                var ani = this.ani;
                if (ani) {
                    ani.displaymc.off(egret.TouchEvent.TOUCH_TAP, this.onStartBtnTouch, this);
                    ani.onRecycle();
                    ani = undefined;
                }
            };
            return NoticePanelMediator;
        }(shao.mvc.Mediator));
        game.NoticePanelMediator = NoticePanelMediator;
        __reflect(NoticePanelMediator.prototype, "shao.game.NoticePanelMediator");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
window["NoticePanelMediator"] = shao.game.NoticePanelMediator;
//# sourceMappingURL=NoticePanelMediator.js.map