var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var NoticePanel = (function (_super) {
            __extends(NoticePanel, _super);
            function NoticePanel() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            NoticePanel.prototype.bindComponents = function () {
            };
            NoticePanel.prototype.init = function () {
                this.skinName = "resource/ui/panel/Notice/NoticePanel.exml";
                // this._key = "Notice"
                // this._thmName = "resource/ui/skin/Notice/notice_thm.json"
            };
            return NoticePanel;
        }(shao.sui.Panel));
        game.NoticePanel = NoticePanel;
        __reflect(NoticePanel.prototype, "shao.game.NoticePanel");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=NoticePanel.js.map