var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var LoginPanel = (function (_super) {
            __extends(LoginPanel, _super);
            function LoginPanel() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            LoginPanel.prototype.bindComponents = function () {
            };
            LoginPanel.prototype.init = function () {
                this.skinName = "resource/ui/panel/Login/LoginPanel.exml";
                // this.skinName = "LoginPanel";
                this._key = "Login";
                // this._thmName = "resource/ui/skin/Login/login_thm.json"
            };
            return LoginPanel;
        }(shao.sui.Panel));
        game.LoginPanel = LoginPanel;
        __reflect(LoginPanel.prototype, "shao.game.LoginPanel");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=LoginPanel.js.map