var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var LoginPanelMediator = (function (_super) {
            __extends(LoginPanelMediator, _super);
            function LoginPanelMediator() {
                return _super.call(this, game.ModuleId.Login) || this;
            }
            LoginPanelMediator.prototype.init = function () {
                this.view = new game.LoginPanel;
                game.ResizeManager.getInstance().add(this.view, 10 /* MIDDLE_CENTER */);
                //这里加事件关注
            };
            LoginPanelMediator.prototype.afterAllReady = function () {
                var view = this.$view;
                var group = this.group = new shao.sui.TabGroup();
                group.addItem(view.tab_login);
                group.addItem(view.tab_regist);
                group.on(-1020 /* GROUP_CHANGE */, this.onGroupChange, this);
                this.btn_login = new shao.sui.SButton(view.btn_login);
            };
            LoginPanelMediator.prototype.onGroupChange = function () {
                var view = this.$view;
                var index = this.group.selectedIndex;
                view.loginview.visible = index == 0;
                view.registview.visible = index == 1;
            };
            LoginPanelMediator.prototype.onLoginBtnTouch = function (e) {
                shao.$facade.toggle(game.ModuleId.ServerSelect);
                shao.$facade.toggle(game.ModuleId.Login);
            };
            LoginPanelMediator.prototype.awake = function () {
                var view = this.$view;
                this.group.selectedIndex = 0;
                this.btn_login.bindTouch(this.onLoginBtnTouch, this);
            };
            LoginPanelMediator.prototype.sleep = function () {
                var view = this.$view;
                this.btn_login.looseTouch(this.onLoginBtnTouch, this);
            };
            return LoginPanelMediator;
        }(shao.mvc.Mediator));
        game.LoginPanelMediator = LoginPanelMediator;
        __reflect(LoginPanelMediator.prototype, "shao.game.LoginPanelMediator");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
window["LoginPanelMediator"] = shao.game.LoginPanelMediator;
//# sourceMappingURL=LoginPanelMediator.js.map