var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var SubtitlesPanel = (function (_super) {
            __extends(SubtitlesPanel, _super);
            function SubtitlesPanel() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SubtitlesPanel.prototype.bindComponents = function () {
            };
            SubtitlesPanel.prototype.init = function () {
                this.skinName = "resource/ui/panel/Subtitles/SubtitlesPanel.exml";
                // this.skinName = "LoginPanel";
                this._key = "Subtitles";
                // this._thmName = "resource/ui/skin/Subtitles/subtitles_thm.json"
            };
            return SubtitlesPanel;
        }(shao.sui.Panel));
        game.SubtitlesPanel = SubtitlesPanel;
        __reflect(SubtitlesPanel.prototype, "shao.game.SubtitlesPanel");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=SubtitlesPanel.js.map