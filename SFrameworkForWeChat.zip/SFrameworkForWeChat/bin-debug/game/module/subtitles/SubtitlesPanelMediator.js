var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var SubtitlesPanelMediator = (function (_super) {
            __extends(SubtitlesPanelMediator, _super);
            function SubtitlesPanelMediator() {
                return _super.call(this, game.ModuleId.Subtitles) || this;
            }
            SubtitlesPanelMediator.prototype.init = function () {
                this.view = new game.SubtitlesPanel;
                game.ResizeManager.getInstance().add(this.view, 10 /* MIDDLE_CENTER */);
                //这里加事件关注
            };
            SubtitlesPanelMediator.prototype.afterAllReady = function () {
                var view = this.$view;
                view.btn_start.visible = false;
                this.btn_start = new shao.sui.SButton(view.btn_start);
                var image = this.subtitle = new shao.sui.Image;
                view.addChild(image);
                image.x = view.maskRect.x;
                image.y = view.maskRect.y + view.maskRect.height;
                image.mask = view.maskRect;
                image.on(3 /* BMP_LOAD_COMPLETE */, this.onBmpLoad, this);
            };
            SubtitlesPanelMediator.prototype.onBmpLoad = function () {
                var image = this.subtitle;
                image.off(3 /* BMP_LOAD_COMPLETE */, this.onBmpLoad, this);
                var tween = shao.Global.getTween(image);
                tween.to({ y: -500 }, 6000).call(this.onTweenCallBack, this);
            };
            SubtitlesPanelMediator.prototype.onTweenCallBack = function () {
                shao.Global.removeTween(this.subtitle);
                var view = this.$view;
                var tween = shao.Global.getTween(view.animImage);
                tween.to({ x: 580 }, 500);
                view.btn_start.visible = true;
            };
            SubtitlesPanelMediator.prototype.onStartBtnTouch = function () {
            };
            SubtitlesPanelMediator.prototype.awake = function () {
                var view = this.$view;
                this.subtitle.source = "story/game_start_story.png";
                this.btn_start.bindTouch(this.onStartBtnTouch, this);
            };
            SubtitlesPanelMediator.prototype.sleep = function () {
                var view = this.$view;
                this.btn_start.looseTouch(this.onStartBtnTouch, this);
            };
            return SubtitlesPanelMediator;
        }(shao.mvc.Mediator));
        game.SubtitlesPanelMediator = SubtitlesPanelMediator;
        __reflect(SubtitlesPanelMediator.prototype, "shao.game.SubtitlesPanelMediator");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
window["SubtitlesPanelMediator"] = shao.game.SubtitlesPanelMediator;
//# sourceMappingURL=SubtitlesPanelMediator.js.map