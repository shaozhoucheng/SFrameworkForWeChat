var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var ConfirmAgreePanelMediator = (function (_super) {
            __extends(ConfirmAgreePanelMediator, _super);
            function ConfirmAgreePanelMediator() {
                return _super.call(this, game.ModuleId.ConfirmAgree) || this;
            }
            ConfirmAgreePanelMediator.prototype.init = function () {
                this.view = new game.ConfirmAgreePanel;
                game.ResizeManager.getInstance().add(this.view, 10 /* MIDDLE_CENTER */);
                //这里加事件关注
            };
            ConfirmAgreePanelMediator.prototype.afterAllReady = function () {
                var view = this.$view;
                var scroller = new shao.sui.Scroller;
                scroller.bindObj(view.txt_confirm, new egret.Rectangle(0, 0, 548, 488));
                this.btn_agree = new shao.sui.SButton(view.btn_agree);
            };
            ConfirmAgreePanelMediator.prototype.onAgreeBtnTouch = function (e) {
                shao.$facade.toggle(game.ModuleId.CreateRole);
                shao.$facade.toggle(game.ModuleId.ConfirmAgree, 0);
            };
            ConfirmAgreePanelMediator.prototype.showConfirm = function () {
                RES.getResByUrl("resource/remote/data/confirm.json", this.onConfirmComplete, this, RES.ResourceItem.TYPE_JSON);
            };
            ConfirmAgreePanelMediator.prototype.onConfirmComplete = function (data, key) {
                var view = this.$view;
                view.txt_confirm.text = data;
                view.txt_confirm.height = view.txt_confirm.textHeight;
            };
            ConfirmAgreePanelMediator.prototype.awake = function () {
                var view = this.$view;
                this.showConfirm();
                this.btn_agree.bindTouch(this.onAgreeBtnTouch, this);
            };
            ConfirmAgreePanelMediator.prototype.sleep = function () {
                var view = this.$view;
                this.btn_agree.looseTouch(this.onAgreeBtnTouch, this);
            };
            return ConfirmAgreePanelMediator;
        }(shao.mvc.Mediator));
        game.ConfirmAgreePanelMediator = ConfirmAgreePanelMediator;
        __reflect(ConfirmAgreePanelMediator.prototype, "shao.game.ConfirmAgreePanelMediator");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
window["ConfirmAgreePanelMediator"] = shao.game.ConfirmAgreePanelMediator;
//# sourceMappingURL=ConfirmAgreePanelMediator.js.map