var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var CreateRolePanelMediator = (function (_super) {
            __extends(CreateRolePanelMediator, _super);
            function CreateRolePanelMediator() {
                return _super.call(this, game.ModuleId.CreateRole) || this;
            }
            CreateRolePanelMediator.prototype.init = function () {
                this.view = new game.CreateRolePanel;
                game.ResizeManager.getInstance().add(this.view, 10 /* MIDDLE_CENTER */);
                //这里加事件关注
            };
            CreateRolePanelMediator.prototype.afterAllReady = function () {
                var view = this.$view;
                this.btn_goto = new shao.sui.SButton(view.btn_goto);
                var group = this.group = new shao.sui.TabGroup();
                for (var i = 1; i <= 16; i++) {
                    var tab = view["tab_" + i];
                    group.addItem(tab);
                }
                group.on(-1020 /* GROUP_CHANGE */, this.onGroupChange, this);
            };
            CreateRolePanelMediator.prototype.onGroupChange = function () {
            };
            CreateRolePanelMediator.prototype.onLoginBtnTouch = function (e) {
                shao.$facade.toggle(game.ModuleId.ServerSelect);
                shao.$facade.toggle(game.ModuleId.Login);
            };
            CreateRolePanelMediator.prototype.onGotoBtnTouch = function () {
                shao.$facade.toggle(game.ModuleId.Subtitles, 1);
                shao.$facade.toggle(game.ModuleId.CreateRole, 0);
            };
            CreateRolePanelMediator.prototype.awake = function () {
                var view = this.$view;
                this.group.selectedIndex = Math.floor(Math.random2(1, 16));
                this.btn_goto.bindTouch(this.onGotoBtnTouch, this);
            };
            CreateRolePanelMediator.prototype.sleep = function () {
                var view = this.$view;
                this.btn_goto.looseTouch(this.onGotoBtnTouch, this);
            };
            return CreateRolePanelMediator;
        }(shao.mvc.Mediator));
        game.CreateRolePanelMediator = CreateRolePanelMediator;
        __reflect(CreateRolePanelMediator.prototype, "shao.game.CreateRolePanelMediator");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
window["CreateRolePanelMediator"] = shao.game.CreateRolePanelMediator;
//# sourceMappingURL=CreateRolePanelMediator.js.map