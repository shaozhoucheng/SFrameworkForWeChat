var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var CreateRolePanel = (function (_super) {
            __extends(CreateRolePanel, _super);
            function CreateRolePanel() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            CreateRolePanel.prototype.bindComponents = function () {
            };
            CreateRolePanel.prototype.init = function () {
                this.skinName = "resource/ui/panel/CreateRole/CreateRolePanel.exml";
                // this.skinName = "LoginPanel";
                this._key = "CreateRole";
                // this._thmName = "resource/ui/skin/CreateRole/createrole_thm.json"
            };
            return CreateRolePanel;
        }(shao.sui.Panel));
        game.CreateRolePanel = CreateRolePanel;
        __reflect(CreateRolePanel.prototype, "shao.game.CreateRolePanel");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=CreateRolePanel.js.map