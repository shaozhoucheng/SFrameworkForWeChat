var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var ModuleChecker = (function () {
            function ModuleChecker() {
            }
            ModuleChecker.prototype.check = function (data, showtip) {
                return true;
            };
            ModuleChecker.prototype.adjustLimitDatas = function (showLimits, limits) {
                return false;
            };
            return ModuleChecker;
        }());
        game.ModuleChecker = ModuleChecker;
        __reflect(ModuleChecker.prototype, "shao.game.ModuleChecker", ["shao.mvc.IModuleChecker", "shao.mvc.ILimitChecker"]);
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=ModuleChecker.js.map