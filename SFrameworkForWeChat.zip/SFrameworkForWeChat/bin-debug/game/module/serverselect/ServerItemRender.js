var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var ServerItemRender = (function (_super) {
            __extends(ServerItemRender, _super);
            function ServerItemRender() {
                var _this = _super.call(this) || this;
                _this.skin = _this.render = new game.CodeServerItemRender();
                return _this;
            }
            ServerItemRender.prototype.bindComponent = function () {
                _super.prototype.bindComponent.call(this);
            };
            ServerItemRender.prototype.awake = function () {
                var render = this.render;
                render.on(egret.TouchEvent.TOUCH_TAP, this.onSkinTouch, this);
            };
            ServerItemRender.prototype.sleep = function () {
                var render = this.render;
                render.off(egret.TouchEvent.TOUCH_TAP, this.onSkinTouch, this);
            };
            ServerItemRender.prototype.onSkinTouch = function () {
                shao.$facade.toggle(game.ModuleId.ServerSelect);
                shao.$facade.toggle(game.ModuleId.Notice);
            };
            ServerItemRender.prototype.setData = function (value) {
                _super.prototype.setData.call(this, value);
                if (!value)
                    return;
                var render = this.render;
                render.label_serverName.text = value.name;
                render.label_serverStatus.text = value.status + "";
            };
            return ServerItemRender;
        }(shao.sui.ListItemRender));
        game.ServerItemRender = ServerItemRender;
        __reflect(ServerItemRender.prototype, "shao.game.ServerItemRender");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=ServerItemRender.js.map