var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var ServerSelectPanelMediator = (function (_super) {
            __extends(ServerSelectPanelMediator, _super);
            function ServerSelectPanelMediator() {
                return _super.call(this, game.ModuleId.ServerSelect) || this;
            }
            ServerSelectPanelMediator.prototype.init = function () {
                this.view = new game.ServerSelectPanel;
                game.ResizeManager.getInstance().add(this.view, 10 /* MIDDLE_CENTER */);
                //这里加事件关注
            };
            ServerSelectPanelMediator.prototype.afterAllReady = function () {
                var view = this.$view;
                var itemList = this.list = new shao.sui.PageList(game.ServerItemRender, 445, 110);
                view.addChild(itemList);
                var scroller = new shao.sui.Scroller();
                var rect = new egret.Rectangle(0, 0, 445, 660);
                scroller.bindObj(this.list, rect);
                // let list = view.serverList
                // list.itemRenderer = ServerItemRender;
                // list.useVirtualLayout = true;
                // /// 填充数据
                // var dsListHeros: Array<Object> = [
                //     { status: 0, name: "伊文捷琳", ip: "127.0.0.1", port: 9090 },
                //     { status: 1, name: "亚特伍德", ip: "127.0.0.1", port: 9090 },
                //     { status: 2, name: "伊妮德2", ip: "127.0.0.1", port: 9090 },
                //     { status: 3, name: "伊妮德3", ip: "127.0.0.1", port: 9090 },
                //     { status: 3, name: "威弗列德", ip: "127.0.0.1", port: 9090 },
                //     { status: 2, name: "鲁宾", ip: "127.0.0.1", port: 9090 },
                //     { status: 1, name: "威弗列德2", ip: "127.0.0.1", port: 9090 },
                //     { status: 1, name: "史帝文", ip: "127.0.0.1", port: 9090 },
                //     { status: 0, name: "哈瑞斯", ip: "127.0.0.1", port: 9090 },
                //     { status: 3, name: "史帝文2", ip: "127.0.0.1", port: 9090 }
                // ];
                // list.dataProvider = new eui.ArrayCollection(dsListHeros);
                var datas = this.testListData = [];
                for (var i = 0; i <= 10; i++) {
                    var vo = new game.ServerVO;
                    vo.status = i;
                    vo.name = "史帝文" + i;
                    vo.ip = "127.0.0.1";
                    vo.port = 9090;
                    datas.push(vo);
                }
            };
            ServerSelectPanelMediator.prototype.awake = function () {
                var view = this.$view;
                this.list.displayList(this.testListData);
            };
            ServerSelectPanelMediator.prototype.sleep = function () {
            };
            return ServerSelectPanelMediator;
        }(shao.mvc.Mediator));
        game.ServerSelectPanelMediator = ServerSelectPanelMediator;
        __reflect(ServerSelectPanelMediator.prototype, "shao.game.ServerSelectPanelMediator");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
window["ServerSelectPanelMediator"] = shao.game.ServerSelectPanelMediator;
//# sourceMappingURL=ServerSelectPanelMediator.js.map