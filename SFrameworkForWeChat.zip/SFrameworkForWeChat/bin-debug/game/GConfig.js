var shao;
(function (shao) {
    var game;
    (function (game) {
        game.ConfigKey = {
            GongNeng: "GongNeng",
        };
        function rP(key, CfgCreator, idkey) {
            if (idkey === void 0) { idkey = "id"; }
            shao.DataLocator.regCommonParser(key, CfgCreator, idkey);
        }
        function rE(key) {
            shao.DataLocator.regExtra(key);
        }
        function initData() {
            var C = game.ConfigKey;
            var P = shao.game;
            rP(C.GongNeng, P.GongNengCfg);
        }
        game.initData = initData;
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=GConfig.js.map