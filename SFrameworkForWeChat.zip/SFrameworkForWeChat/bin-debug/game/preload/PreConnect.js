var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var PreConnect = (function () {
            function PreConnect() {
                this.initWEB();
            }
            PreConnect.prototype.initWEB = function () {
                var webServer = new shao.WSNetService;
                var param = egret["server"];
                // egret["server"] = {
                // 	ip:server.extrenalIP,
                // 	port:server.tcpPort
                // }
                var wsUrl = "ws://{0}:{1}/websocket".substitute(param.ip, param.port);
                // alert(wsUrl);
                webServer.setUrl(wsUrl);
                webServer.connect();
                //szc 屏蔽
                // Core.socket = webServer;
            };
            return PreConnect;
        }());
        game.PreConnect = PreConnect;
        __reflect(PreConnect.prototype, "shao.game.PreConnect");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=PreConnect.js.map