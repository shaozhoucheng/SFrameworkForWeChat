var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var PreLoader = (function () {
            /**初始化加载
             * 1.加载des.res.json
             * 2.加载resource_ui.json(后面优化成部分ui走preload 进入游戏后再加载resouce_ui.json)
             * 3.加载des.thm.json
             */
            function PreLoader() {
                // private newLoader(evt: egret.Event) {
                //     // RES.loadConfig("resource/default.res.json" + "?v=" + Math.random(), "resource/", RES.ResourceItem.TYPE_JSON);
                //     let key = "preload3";
                //     RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete2, this);
                //     RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress2, this);
                //     // RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this);
                //     // RES.addEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onItemLoadError, this);
                //     RES.loadGroup(key);
                // }
                // private onReshowLoader(evt: egret.Event) {
                //     if (!this.reLoaded) {
                //         // this.loadUI.visible = true;
                //     }
                // }
                this._loadFlag = false;
                // private reLoaded: boolean = false;
                /**
                 * preload资源组加载完成
                 * Preload resource group is loaded
                 */
                // private onResourceLoadComplete2(event: RES.ResourceEvent): void {
                //     this.reLoaded = true;
                //     DataLocator.parsePakedDatas();
                //     // removeDisplay(this.loadUI);
                // }
                this._dataFlag = false;
                var loadUI = shao.getInstance(game.LoadingUI);
                loadUI.showLoadUI(this.initRES, this);
                shao.mvc.Facade.on(-159 /* DATA_LOCATOR */, this.dataParsed, this);
                //szc 屏蔽
                // return;
                // let base = egret["baseParams"];
                // let newPlayer = base["newPlayer"];
                // if (newPlayer) {
                //     mvc.Facade.on(shao.EventConst.NEW_LOADER_START, this.newLoader, this);
                //     //szc 屏蔽
                //     // mvc.Facade.on(BaseService.BEFORE_ENTER_GAME, this.onReshowLoader, this);
                //     // if (DEBUG) {
                //     //     mvc.Facade.on(lingyu.EventConst.DATA_LOCATOR, this.dataParsed, this);
                //     // }
                // } else {
                //     mvc.Facade.on(EventConst.DATA_LOCATOR, this.dataParsed, this);
                // }
            }
            PreLoader.prototype.startLoading = function (e) {
                this._loadFlag = true;
                shao.PBMessageUtils.structByName = PBMsgDict;
                //初始化模块处理
                var mm = new shao.mvc.ModuleManager();
                shao.$facade.bindModuleManager(mm);
                this.initMoudleChecker();
                var cfgs = shao.DataLocator.getData(game.ConfigKey.GongNeng);
                mm.setCfgs(cfgs);
                mm.registerHandler(0, new game.ModuleHandler0());
                // Core.stage.addChild(new ServerMainPanel());
                if (this._dataFlag && this._loadFlag) {
                    // $facade.toggle(ModuleId.Login);//打开选服页面
                    shao.getInstance(shao.SceneManager).runScene(game.SceneConst.Login);
                }
            };
            PreLoader.prototype.initMoudleChecker = function () {
                var mm = shao.$facade.moduleManager;
                var checks;
                checks = {};
                checks[1] = new game.ModuleChecker();
                mm.checkers = checks;
            };
            PreLoader.prototype.initRES = function () {
                // this.defaultTime = Date.now();
                RES.addEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
                if (true) {
                    RES.loadConfig("resource/default.res.json", "resource/");
                }
                else {
                    // RES.loadConfig(Core.domain + "/resource/default.res.json" + "?v=" + Math.random(), Core.domain + "/resource/", RES.ResourceItem.TYPE_JSON);
                }
            };
            PreLoader.prototype.onConfigComplete = function (event) {
                // let base = egret["baseParams"];
                // let newFlag = base["newPlayer"];
                // let key;
                // if (newFlag) {
                //     key = "preload2";
                // } else {
                //     key = "preload";
                // }
                // key = "preload";
                RES.removeEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
                RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onPreloadGroupComplete, this);
                RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this);
                RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this);
                RES.addEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onItemLoadError, this);
                RES.loadGroup("preload");
            };
            PreLoader.prototype.onPreloadGroupComplete = function () {
                RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onPreloadGroupComplete, this);
                RES.removeEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this);
                RES.removeEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onItemLoadError, this);
                RES.removeEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this);
                RES.addEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onUIResComplete, this);
                RES.loadConfig("resource/resource_ui.json", "resource/");
            };
            PreLoader.prototype.onUIResComplete = function () {
                var _this = this;
                RES.removeEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onUIResComplete, this);
                var theme = new eui.Theme("resource/default.thm.json", game.Core.stage);
                theme.addEventListener(eui.UIEvent.COMPLETE, function () {
                    _this.onResourceLoadComplete();
                }, this);
            };
            PreLoader.prototype.onResourceProgress = function (event) {
                var item = event.resItem;
                // let desType = item.data.des;
                var progress = event.itemsLoaded / event.itemsTotal * 100;
                // let showString = `正在加载${[desType]}`
                // let totalString = `正在加载第${[event.itemsLoaded]}个，共${[event.itemsTotal]}个`;
                // this.loadUI.showDesc(totalString + showString);
                shao.getInstance(game.LoadingUI).showProgress(event.itemsLoaded, event.itemsTotal);
                // ConfigUtils.setPreloadRes(item.url, item.name);
                // let pro = $Int((event.itemsLoaded/event.itemsTotal)*100);
                // if(RELEASE){
                //      reportProgress(pro);
                // }
            };
            // private onResourceProgress2(event: RES.ResourceEvent) {
            //     let item = event.resItem;
            //     // let desType = item.data.des;
            //     // let showString = `正在加载${[desType]}`
            //     // let totalString = `正在加载第${[event.itemsLoaded]}个，共${[event.itemsTotal]}个`;
            //     // this.loadUI.showDesc(totalString + showString);
            //     // this.loadUI.showProgress(event.itemsLoaded, event.itemsTotal);
            //     ConfigUtils.setPreloadRes(item.url, item.name);
            // }
            /**
           * preload资源组加载完成
           * Preload resource group is loaded
           */
            PreLoader.prototype.onResourceLoadComplete = function (event) {
                // let base = egret["baseParams"];
                // let newPlayer = base["newPlayer"];
                // if (!newPlayer) {
                //     // removeDisplay(this.loadUI);
                // } else {
                //     // this.loadUI.visible = false;
                // }
                shao.removeDisplay(shao.getInstance(game.LoadingUI));
                var m = document.getElementById("Main");
                if (m) {
                    m.style.backgroundImage = "";
                }
                //前期事件管理器（启动游戏后，不建议使用)
                // FacadeInterest.getInstance().start();
                //解析配置数据
                var gameRes = RES.getRes("game");
                game.initData();
                shao.ConfigUtils.setData(gameRes);
                var ConfigKey = game.ConfigKey;
                // NameUtils.loadNameLib(gameRes.params.nameLib);
                // WordFilter.loadDirtyWord(gameRes.params.dirty);
                // LangUtil.loadCode(gameRes.params.code);
                // DataLocator.regParser(ConfigKey.MAP, MapConfigParser);
                // DataLocator.regParser(ConfigKey.PST, PstConfigParser);
                // DataLocator.regParser(ConfigKey.ANI, AniConfigParser);
                // ResourceManager.init();
                // sui.SuiResManager.getInstance().setInlineData("lib", RES.getRes("s_libs"));
                // if (!newPlayer) {
                //配置cfgs
                shao.DataLocator.parsePakedDatas();
                // } else {
                //     //配置数据特殊处理
                //     DataLocator.parseRegiest();
                //     this._dataFlag = true;
                //     this.startLoading();
                // }
            };
            PreLoader.prototype.dataParsed = function (e) {
                this._dataFlag = true;
                this.startLoading();
            };
            PreLoader.prototype.onResourceLoadError = function (event) {
                shao.ThrowError("Group:" + event.groupName + " has failed to load");
                this.onResourceLoadComplete(event);
            };
            /**
           * 资源组加载出错
           *  The resource group loading failed
           */
            PreLoader.prototype.onItemLoadError = function (event) {
                shao.ThrowError("Url:" + event.resItem.url + " has failed to load");
            };
            return PreLoader;
        }());
        game.PreLoader = PreLoader;
        __reflect(PreLoader.prototype, "shao.game.PreLoader");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=PreLoader.js.map