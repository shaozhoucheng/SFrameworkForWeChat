var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var PreRegiest = (function () {
            function PreRegiest() {
                this.initREG();
            }
            PreRegiest.prototype.initREG = function () {
                var facade = shao.$facade;
                // //初始化模块处理
                facade.registerInlineMediator(game.ServerSelectPanelMediator, game.ModuleId.ServerSelect);
                facade.registerInlineMediator(game.NoticePanelMediator, game.ModuleId.Notice);
                facade.registerInlineMediator(game.ConfirmAgreePanelMediator, game.ModuleId.ConfirmAgree);
                facade.registerInlineMediator(game.CreateRolePanelMediator, game.ModuleId.CreateRole);
                facade.registerInlineMediator(game.SubtitlesPanelMediator, game.ModuleId.Subtitles);
                //注册服务
                // facade.registerInlineProxy(LoginService,ServiceName.LoginService);
                // facade.registerInlineProxy(ItemsService,ServiceName.ItemsService);
                //绑定面板处理器和功能标识
                //以下是运营活动面板
            };
            return PreRegiest;
        }());
        game.PreRegiest = PreRegiest;
        __reflect(PreRegiest.prototype, "shao.game.PreRegiest");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=PreRegiest.js.map