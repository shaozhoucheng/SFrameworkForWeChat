var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var StoryScene = (function (_super) {
            __extends(StoryScene, _super);
            /**
             * 构造函数
             */
            function StoryScene() {
                return _super.call(this) || this;
            }
            /**
             * 进入Scene调用
             */
            StoryScene.prototype.onEnter = function () {
                _super.prototype.onEnter.call(this);
                shao.$facade.toggle(game.ModuleId.ConfirmAgree, 1);
            };
            /**
             * 退出Scene调用
             */
            StoryScene.prototype.onExit = function () {
                _super.prototype.onExit.call(this);
            };
            return StoryScene;
        }(shao.BaseScene));
        game.StoryScene = StoryScene;
        __reflect(StoryScene.prototype, "shao.game.StoryScene");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=StoryScene.js.map