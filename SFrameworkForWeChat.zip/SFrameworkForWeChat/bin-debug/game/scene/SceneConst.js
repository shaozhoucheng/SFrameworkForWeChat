var shao;
(function (shao) {
    var game;
    (function (game) {
        var SceneConst;
        (function (SceneConst) {
            /**
             * 登录场景
             * @type {number}
             */
            SceneConst[SceneConst["Login"] = 1] = "Login";
            /**
             * 故事场景
             * @type {number}
             */
            SceneConst[SceneConst["Story"] = 2] = "Story";
            /**
             * 家园场景
             * @type {number}
             */
            SceneConst[SceneConst["Home"] = 3] = "Home";
        })(SceneConst = game.SceneConst || (game.SceneConst = {}));
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=SceneConst.js.map