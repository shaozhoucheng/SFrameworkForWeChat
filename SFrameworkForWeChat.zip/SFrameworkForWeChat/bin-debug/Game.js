var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var shao;
(function (shao) {
    var game;
    (function (game) {
        var Game = (function (_super) {
            __extends(Game, _super);
            function Game() {
                var _this = _super.call(this) || this;
                egret.ImageLoader.crossOrigin = "anonymous";
                shao.Global.initTick();
                _this.on(egret.Event.ADDED_TO_STAGE, _this.onAddToStage, _this);
                RES.setMaxLoadingThread(4);
                return _this;
            }
            Game.prototype.onAddToStage = function (event) {
                egret.lifecycle.addLifecycleListener(function (context) {
                    // custom lifecycle plugin
                });
                egret.lifecycle.onPause = function () {
                    egret.ticker.pause();
                };
                egret.lifecycle.onResume = function () {
                    egret.ticker.resume();
                };
                //inject the custom material parser
                //注入自定义的素材解析器
                var assetAdapter = new AssetAdapter();
                egret.registerImplementation("eui.IAssetAdapter", assetAdapter);
                egret.registerImplementation("eui.IThemeAdapter", new ThemeAdapter());
                this.initScene();
                // this.runGame().catch(e => {
                //     console.log(e);
                // })
                this.createGameScene();
            };
            // private async runGame() {
            //     // await this.loadResource()
            //     this.createGameScene();
            //     // const result = await RES.getResAsync("description_json",null,this)
            //     // await platform.login();
            //     // const userInfo = await platform.getUserInfo();
            //     // console.log(userInfo);
            // }
            Game.prototype.createGameScene = function () {
                var stage = this.stage;
                // stage.dirtyRegionPolicy = "off";
                game.ResizeManager.getInstance().init(stage);
                shao.$facade = new shao.mvc.Facade();
                // $facade.registerInlineMediator(ServerMainPanelMediator, ModuleId.Servers);
                game.Core.stage = stage;
                // sui.Panel.WIDTH = stage.stageWidth;
                // sui.Panel.HEIGHT = stage.stageHeight;
                game.GameEngine.init(stage);
                // let engine = game.GameEngine.instance;
                // let camera = new game.Camera();
                // engine.camera = camera;
                // stage.on(egret.Event.RESIZE, () => {
                //     camera.setSize(stage.stageWidth, stage.stageHeight);
                //     sui.Panel.WIDTH = stage.stageWidth;
                //     sui.Panel.HEIGHT = stage.stageHeight;
                // }, this)
                // let scale = devicePixelRatio;
                // console.log(scale);
                // Core.domain = param.domain;
                // Core.loader = param.loader;
                // mvc.Facade.on(shao.NetEvent.WEB_COMPLETE, this.connectHandler, this);
                // mvc.Facade.on(shao.NetEvent.WEB_FAILED, this.failHandler, this);
                new game.PreLoader();
            };
            /**
         * 初始化所有场景
         */
            Game.prototype.initScene = function () {
                shao.getInstance(shao.SceneManager).register(game.SceneConst.Login, new game.LoginScene());
                shao.getInstance(shao.SceneManager).register(game.SceneConst.Story, new game.StoryScene());
                shao.getInstance(shao.SceneManager).register(game.SceneConst.Home, new game.HomeScene());
            };
            // private async loadResource() {
            //     try {
            //         // const loadingView = new LoadingUI();
            //         // this.stage.addChild(loadingView);
            //         await RES.loadConfig("resource/default.res.json", "resource/");
            //         await RES.loadConfig("resource/resource_ui.json", "resource/");
            //         await this.loadTheme();
            //         await RES.loadGroup("preload");
            //         // this.stage.removeChild(loadingView);
            //     }
            //     catch (e) {
            //         console.error(e);
            //     }
            // }
            // private loadTheme() {
            //     return new Promise((resolve, reject) => {
            //         // load skin theme configuration file, you can manually modify the file. And replace the default skin.
            //         //加载皮肤主题配置文件,可以手动修改这个文件。替换默认皮肤。
            //         let theme = new eui.Theme("resource/default.thm.json", this.stage);
            //         theme.addEventListener(eui.UIEvent.COMPLETE, () => {
            //             resolve();
            //         }, this);
            //     })
            // }
            Game.prototype.failHandler = function () {
                // $reportGameStep(gameReport.SOCKET_CONN_FAIL);
            };
            return Game;
        }(egret.DisplayObjectContainer));
        game.Game = Game;
        __reflect(Game.prototype, "shao.game.Game");
    })(game = shao.game || (shao.game = {}));
})(shao || (shao = {}));
//# sourceMappingURL=Game.js.map