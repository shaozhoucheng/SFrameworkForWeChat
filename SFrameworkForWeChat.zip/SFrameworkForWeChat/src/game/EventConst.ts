module shao {
    export const enum EventConst {
        /*-*begin sideMediator*-*/
        SIDE_MODULE_SHOW,

        SIDE_MODULE_HIDE,
        /*-*end sideMediator*-*/
        NEW_LOADER_START,

        /**位图加载成功*/
        BMP_LOAD_COMPLETE,
    }
}