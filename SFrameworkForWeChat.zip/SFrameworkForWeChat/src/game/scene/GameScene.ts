module shao.game {
    export class GameScene extends BaseScene {
        /**
         * 构造函数
         */
        public constructor() {
            super();
        }

        /**
         * 进入Scene调用
         */
        public onEnter(): void {
            super.onEnter();
        }

        /**
         * 退出Scene调用
         */
        public onExit(): void {
            super.onExit();
        }
    }
}