module shao.game {
    export class ServerVO {
        public status: number;
        public name: string;
        public port: number;
        public ip: string;
    }
}