module shao {
	/**
	 * 客户端检测
	 * @author builder
	 *
	 */
	export class ClientCheck {
    	/**
    	 * 是否做客户端检查
    	 */
		public static isClientCheck: boolean = true;
	}
}
