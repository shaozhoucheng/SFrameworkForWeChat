module shao.sui {
	export class SButton {
		public constructor(btn: eui.Button) {
			// super();
			this._btn = btn;
			this.setTouchUtil(true);
		}
		protected _btn: eui.Button;

		protected touchUtil: TouchUtil;
		public set enabled(value: boolean) {
			if (this.enabled != value) {
				// this.filters = value ? null : FilterUtil.DarkGrayFilter;
			}
			this.setTouchUtil(value);
		}

		public setTouchUtil(value: boolean) {
			let util = this.touchUtil;
			if (util == undefined && value) {
				util = this.touchUtil = new TouchUtil(this._btn);
			}
			if (util) {
				util.enabled = value;
			}
		}

		/**
		 * 绑定TOUCH_TAP的回调
		 * 
		 * @param {Function} handler
		 * @param {*} thisObject
		 * @param {number} [priority]
		 * @param {boolean} [useCapture]
		 * 
		 * @memberOf Button
		 */
		public bindTouch(handler: Function, thisObject: any, priority?: number, useCapture?: boolean) {
			this._btn.on(egret.TouchEvent.TOUCH_TAP, handler, thisObject, useCapture, priority);
		}

		/**
		 * 解除TOUCH_TAP的回调的绑定
		 * 
		 * @param {Function} handler
		 * @param {*} thisObject
		 * @param {boolean} [useCapture]
		 * 
		 * @memberOf Button
		 */
		public looseTouch(handler: Function, thisObject: any, useCapture?: boolean) {
			this._btn.off(egret.TouchEvent.TOUCH_TAP, handler, thisObject, useCapture);
		}
	}
}