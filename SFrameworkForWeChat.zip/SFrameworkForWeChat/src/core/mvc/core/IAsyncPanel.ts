module shao.mvc {
	/**
	 *
	 * @author 
	 *
	 */
	export interface IAsyncPanel extends egret.DisplayObject,IAsync,IModulePanel{
		
	}
}
